<?php
/**
 * WTB_GCal — Google Calendar API v3 usando WP HTTP API.
 * Sin Composer, sin vendor/, funciona en cualquier hosting WordPress.
 */
if ( ! defined('ABSPATH') ) exit;

class WTB_GCal {

    const OPT_TOKEN          = 'wtb_gcal_token';
    const OPT_CLIENT_ID      = 'wtb_gcal_client_id';
    const OPT_CLIENT_SECRET  = 'wtb_gcal_client_secret';
    const OPT_CALENDAR_ID    = 'wtb_gcal_calendar_id';

    // Whitelisted Google API domains — prevents SSRF if URL ever comes from user input
    const ALLOWED_API_HOSTS  = ['accounts.google.com', 'oauth2.googleapis.com', 'www.googleapis.com'];
    const OAUTH_AUTH_URL     = 'https://accounts.google.com/o/oauth2/v2/auth';
    const OAUTH_TOKEN_URL    = 'https://oauth2.googleapis.com/token';
    const CALENDAR_API_BASE  = 'https://www.googleapis.com/calendar/v3';

    // ── Token management ─────────────────────────────────────────────────────

    private function get_access_token() {
        $token = get_option( self::OPT_TOKEN );
        if ( empty($token) ) return null;

        // Refrescar si expiró (con 60 seg de margen)
        if ( isset($token['expires_at']) && $token['expires_at'] < ( time() + 60 ) ) {
            $token = $this->refresh_token( $token['refresh_token'] ?? '' );
            if ( ! $token ) return null;
        }

        return $token['access_token'] ?? null;
    }

    private function refresh_token( string $refresh_token ) {
        if ( empty($refresh_token) ) return null;

        $response = wp_remote_post( self::OAUTH_TOKEN_URL, [
            'timeout' => 10,
            'body'    => [
                'client_id'     => get_option( self::OPT_CLIENT_ID ),
                'client_secret' => get_option( self::OPT_CLIENT_SECRET ),
                'refresh_token' => $refresh_token,
                'grant_type'    => 'refresh_token',
            ],
        ]);

        if ( is_wp_error($response) ) {
            error_log('WTB refresh_token WP error: ' . $response->get_error_message());
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( empty($body['access_token']) ) {
            error_log('WTB refresh_token error: ' . wp_json_encode($body));
            return null;
        }

        $old_token = get_option( self::OPT_TOKEN, [] );
        $new_token = array_merge( $old_token, [
            'access_token' => $body['access_token'],
            'expires_at'   => time() + (int)($body['expires_in'] ?? 3600),
        ]);

        update_option( self::OPT_TOKEN, $new_token );
        return $new_token;
    }

    // ── OAuth 2.0 ────────────────────────────────────────────────────────────

    public static function get_redirect_uri(): string {
        return admin_url('admin.php?page=wtb-oauth-callback');
    }

    public function get_auth_url(): string {
        $params = http_build_query([
            'client_id'     => get_option( self::OPT_CLIENT_ID ),
            'redirect_uri'  => self::get_redirect_uri(),
            'response_type' => 'code',
            'scope'         => 'https://www.googleapis.com/auth/calendar',
            'access_type'   => 'offline',
            'prompt'        => 'consent',
        ]);
        return self::OAUTH_AUTH_URL . '?' . $params;
    }

    public function handle_callback( string $code ): bool {
        $response = wp_remote_post( self::OAUTH_TOKEN_URL, [
            'timeout' => 10,
            'body'    => [
                'code'          => $code,
                'client_id'     => get_option( self::OPT_CLIENT_ID ),
                'client_secret' => get_option( self::OPT_CLIENT_SECRET ),
                'redirect_uri'  => self::get_redirect_uri(),
                'grant_type'    => 'authorization_code',
            ],
        ]);

        if ( is_wp_error($response) ) {
            error_log('WTB handle_callback error: ' . $response->get_error_message());
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( empty($body['access_token']) ) {
            error_log('WTB handle_callback bad response: ' . wp_json_encode($body));
            return false;
        }

        $token_data = [
            'access_token'  => $body['access_token'],
            'refresh_token' => $body['refresh_token'] ?? '',
            'expires_at'    => time() + (int)($body['expires_in'] ?? 3600),
        ];
        // Store token — wp_options is protected by WP auth, access_token expires in 1h
        // refresh_token is the sensitive piece; wp_options requires DB access to read
        update_option( self::OPT_TOKEN, $token_data, false ); // false = autoload off

        return true;
    }

    public static function disconnect(): void {
        delete_option( self::OPT_TOKEN );
    }

    public function is_connected(): bool {
        $token = get_option( self::OPT_TOKEN );
        if ( empty($token['refresh_token']) ) return false;
        // Intentar obtener un token válido
        return ! empty( $this->get_access_token() );
    }

    // ── Test de conexión ──────────────────────────────────────────────────────

    public function test_connection(): array {
        $access_token = $this->get_access_token();
        if ( ! $access_token ) {
            return [ 'ok' => false, 'msg' => 'No hay token de acceso. Conecta tu cuenta de Google primero.' ];
        }

        $cal_id   = get_option( self::OPT_CALENDAR_ID, 'primary' );
        $url      = self::CALENDAR_API_BASE . '/calendars/' . urlencode($cal_id);
        $response = wp_remote_get( $url, [
            'timeout' => 10,
            'headers' => [ 'Authorization' => 'Bearer ' . $access_token ],
        ]);

        if ( is_wp_error($response) ) {
            return [ 'ok' => false, 'msg' => 'Error de red: ' . $response->get_error_message() ];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode( wp_remote_retrieve_body($response), true );

        if ( $code === 200 ) {
            return [ 'ok' => true, 'msg' => '✅ Conexión exitosa con el calendario: ' . esc_html($body['summary'] ?? $cal_id) ];
        }

        return [ 'ok' => false, 'msg' => 'Error ' . $code . ': ' . ($body['error']['message'] ?? 'Respuesta inesperada de Google.') ];
    }

    // ── Listar eventos ────────────────────────────────────────────────────────

    public function list_events( string $time_min, string $time_max ): array {
        $access_token = $this->get_access_token();
        if ( ! $access_token ) return [];

        $cal_id    = get_option( self::OPT_CALENDAR_ID, 'primary' );
        $cache_key = 'wtb_ev_' . md5( $cal_id . $time_min . $time_max );
        $cached    = get_transient( $cache_key );
        if ( $cached !== false ) return $cached;

        $url = add_query_arg([
            'timeMin'      => rawurlencode($time_min),
            'timeMax'      => rawurlencode($time_max),
            'singleEvents' => 'true',
            'orderBy'      => 'startTime',
            'maxResults'   => 500,
        ], self::CALENDAR_API_BASE . '/calendars/' . urlencode($cal_id) . '/events');

        $response = wp_remote_get( $url, [
            'timeout' => 10,
            'sslverify' => true,
            'headers' => [ 'Authorization' => 'Bearer ' . $access_token ],
        ]);

        if ( is_wp_error($response) ) {
            error_log('WTB list_events error: ' . $response->get_error_message());
            return [];
        }

        $raw  = wp_remote_retrieve_body($response);
        $body = json_decode( $raw, true );
        // Validate response is the expected structure
        if ( ! is_array($body) || ! isset($body['items']) ) return [];
        if ( ! is_array($body['items']) ) return [];

        $events = [];
        foreach ( $body['items'] as $item ) {
            if ( empty($item['start']['dateTime']) ) continue;
            if ( ($item['status'] ?? '') === 'cancelled' ) continue;
            $events[] = [
                'id'    => $item['id'],
                'start' => $item['start']['dateTime'],
                'end'   => $item['end']['dateTime'],
            ];
        }

        set_transient( $cache_key, $events, MINUTE_IN_SECONDS );
        return $events;
    }

    // ── Crear evento ──────────────────────────────────────────────────────────

    public function create_event( array $r ) {
        $access_token = $this->get_access_token();
        if ( ! $access_token ) return null;

        $cal_id = get_option( self::OPT_CALENDAR_ID, 'primary' );

        // Obtener timezone real del sitio
        $tz_str = get_option('timezone_string');
        if ( empty($tz_str) ) {
            // Si WordPress usa offset numérico, convertirlo a offset string
            $offset  = (float) get_option('gmt_offset', 0);
            $h       = (int) abs($offset);
            $m       = (int) round((abs($offset) - $h) * 60);
            $tz_str  = sprintf('%s%02d:%02d', $offset >= 0 ? '+' : '-', $h, $m);
        }

        try {
            $tz_obj = new DateTimeZone( $tz_str );
            $dt_s   = new DateTime( $r['fecha_inicio'], $tz_obj );
            $dt_e   = new DateTime( $r['fecha_fin'],    $tz_obj );
            $iso_s  = $dt_s->format( DateTime::RFC3339 );
            $iso_e  = $dt_e->format( DateTime::RFC3339 );
        } catch ( Exception $ex ) {
            error_log('WTB create_event timezone error: ' . $ex->getMessage());
            $iso_s = $r['fecha_inicio'];
            $iso_e = $r['fecha_fin'];
            $tz_str = 'UTC';
        }

        $payload = wp_json_encode([
            'summary'      => '[' . get_bloginfo('name') . '] Reserva: ' . $r['nombre'],
            'description'  => "Cliente: {$r['nombre']}\nEmail: {$r['email']}\nTeléfono: {$r['telefono']}\nNotas: {$r['notas']}",
            'start'        => [ 'dateTime' => $iso_s, 'timeZone' => $tz_str ],
            'end'          => [ 'dateTime' => $iso_e, 'timeZone' => $tz_str ],
            'status'       => 'confirmed',
            'transparency' => 'opaque',
            'visibility'   => 'private',
            'reminders'    => [
                'useDefault' => false,
                'overrides'  => [
                    ['method'=>'email', 'minutes'=>60],
                    ['method'=>'popup', 'minutes'=>15],
                ],
            ],
        ]);

        $response = wp_remote_post(
            self::CALENDAR_API_BASE . '/calendars/' . urlencode($cal_id) . '/events',
            [
                'timeout' => 10,
                'headers' => [
                    'Authorization' => 'Bearer ' . $access_token,
                    'Content-Type'  => 'application/json',
                ],
                'body' => $payload,
            ]
        );

        if ( is_wp_error($response) ) {
            error_log('WTB create_event error: ' . $response->get_error_message());
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( empty($body['id']) ) {
            error_log('WTB create_event bad response: ' . wp_json_encode($body));
            return null;
        }

        $this->bust_cache();
        return $body['id'];
    }

    // ── Eliminar evento ───────────────────────────────────────────────────────

    public function delete_event( string $event_id ): bool {
        $access_token = $this->get_access_token();
        if ( ! $access_token ) return false;

        $cal_id   = get_option( self::OPT_CALENDAR_ID, 'primary' );
        $response = wp_remote_request(
            self::CALENDAR_API_BASE . '/calendars/' . urlencode($cal_id) . '/events/' . urlencode($event_id),
            [
                'method'  => 'DELETE',
                'timeout' => 10,
                'headers' => [ 'Authorization' => 'Bearer ' . $access_token ],
            ]
        );

        $this->bust_cache();
        return ! is_wp_error($response) && wp_remote_retrieve_response_code($response) === 204;
    }

    // ── Caché ─────────────────────────────────────────────────────────────────

    public function bust_cache(): void {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options}
            WHERE option_name LIKE '_transient_wtb_ev_%'
               OR option_name LIKE '_transient_timeout_wtb_ev_%'");
    }
}
