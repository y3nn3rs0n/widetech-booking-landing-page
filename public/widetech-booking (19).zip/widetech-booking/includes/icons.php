<?php
if ( ! defined('ABSPATH') ) exit;

/**
 * Render a WTB SVG icon inline.
 * @param string $name   Icon ID from icons.svg (without "wtb-icon-" prefix)
 * @param string $class  Extra CSS classes
 * @param int    $size   Size in pixels (default 18)
 */
function wtb_icon( string $name, string $class = '', int $size = 18 ): string {
    return sprintf(
        '<svg class="wtb-icon %s" width="%d" height="%d" aria-hidden="true" focusable="false">
            <use href="#wtb-icon-%s"/>
        </svg>',
        esc_attr( $class ),
        $size, $size,
        esc_attr( $name )
    );
}

/**
 * Output the SVG sprite (once, in admin head)
 */
function wtb_icon_sprite(): void {
    $path = WTB_PATH . 'assets/img/icons.svg';
    if ( file_exists($path) ) {
        echo '<div style="display:none;position:absolute;width:0;height:0;overflow:hidden;">';
        echo file_get_contents( $path ); // phpcs:ignore
        echo '</div>';
    }
}
add_action('admin_footer', 'wtb_icon_sprite');
