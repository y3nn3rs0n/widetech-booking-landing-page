<?php if ( ! defined('ABSPATH') ) exit;

/* ═══════════════════════════════════════════════════════════════════
   WTB_Database
═══════════════════════════════════════════════════════════════════ */
class WTB_Database {
    const TABLE = 'wtb_reservas';

    public static function create_table(): void {
        global $wpdb;
        $t  = $wpdb->prefix . self::TABLE;
        $ch = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE IF NOT EXISTS {$t} (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            gcal_event_id VARCHAR(255)  DEFAULT '',
            nombre        VARCHAR(100)  NOT NULL,
            email         VARCHAR(100)  NOT NULL,
            telefono      VARCHAR(30)   DEFAULT '',
            notas         TEXT,
            fecha_inicio  DATETIME      NOT NULL,
            fecha_fin     DATETIME      NOT NULL,
            estado        ENUM('confirmada','cancelada') DEFAULT 'confirmada',
            origen        ENUM('web','gcal','manual')    DEFAULT 'web',
            creado_en     DATETIME      DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_fi  (fecha_inicio),
            KEY idx_gc  (gcal_event_id),
            KEY idx_est (estado)
        ) {$ch};");
    }

    public static function insert( array $d ) {
        global $wpdb;
        $ok = $wpdb->insert( $wpdb->prefix . self::TABLE, [
            'gcal_event_id' => sanitize_text_field( $d['gcal_event_id'] ?? '' ),
            'nombre'        => sanitize_text_field( $d['nombre'] ),
            'email'         => sanitize_email(      $d['email'] ),
            'telefono'      => sanitize_text_field( $d['telefono'] ?? '' ),
            'notas'         => sanitize_textarea_field( $d['notas'] ?? '' ),
            'fecha_inicio'  => $d['fecha_inicio'],
            'fecha_fin'     => $d['fecha_fin'],
            'estado'        => 'confirmada',
            'origen'        => $d['origen'] ?? 'web',
        ], ['%s','%s','%s','%s','%s','%s','%s','%s','%s'] );
        return $ok ? $wpdb->insert_id : false;
    }

    public static function is_available( string $ini, string $fin ): bool {
        global $wpdb;
        $t = $wpdb->prefix . self::TABLE;
        return 0 === (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$t} WHERE estado='confirmada' AND fecha_inicio<%s AND fecha_fin>%s",
            $fin, $ini
        ));
    }

    public static function get_all( int $limit = 50, int $offset = 0 ): array {
        global $wpdb;
        $t = $wpdb->prefix . self::TABLE;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$t} ORDER BY fecha_inicio DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ), ARRAY_A ) ?: [];
    }

    public static function count(): int {
        global $wpdb;
        return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . self::TABLE );
    }

    public static function cancel_by_gcal( string $gcal_id ): void {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . self::TABLE,
            ['estado' => 'cancelada'], ['gcal_event_id' => $gcal_id], ['%s'], ['%s'] );
    }
}

/* ═══════════════════════════════════════════════════════════════════
   WTB_REST_API
═══════════════════════════════════════════════════════════════════ */
class WTB_REST_API {
    const NS = 'wtb/v1';
    public function __construct() {
        add_action('rest_api_init', [$this,'register_routes']);
    }
    public function register_routes(): void {
        register_rest_route(self::NS,'/slots',[
            'methods'=>'GET','callback'=>[$this,'get_slots'],'permission_callback'=>'__return_true',
            'args'=>['start'=>['required'=>true,'sanitize_callback'=>'sanitize_text_field'],
                     'end'  =>['required'=>true,'sanitize_callback'=>'sanitize_text_field']],
        ]);
        register_rest_route(self::NS,'/reservar',[
            'methods'=>'POST','callback'=>[$this,'crear_reserva'],'permission_callback'=>'__return_true',
        ]);
        // Test conexión (solo admin)
        register_rest_route(self::NS,'/test-connection',[
            'methods'=>'POST','callback'=>[$this,'test_connection'],
            'permission_callback'=>fn()=>current_user_can('manage_options'),
        ]);
    }

    public function get_slots( WP_REST_Request $req ): WP_REST_Response {
        // Validate date range sanity: max 3 months span to prevent resource exhaustion
        $start_raw = $req->get_param('start');
        $end_raw   = $req->get_param('end');
        if ( ! $start_raw || ! $end_raw ) {
            return new WP_REST_Response(['error'=>'Parámetros requeridos.'], 400);
        }
        try {
            $dt_check_s = new DateTime($start_raw);
            $dt_check_e = new DateTime($end_raw);
            $diff_days  = $dt_check_s->diff($dt_check_e)->days;
            if ( $diff_days > 100 ) { // Max 100 days span
                return new WP_REST_Response(['error'=>'Rango de fechas demasiado amplio.'], 400);
            }
        } catch ( Exception $ex ) {
            return new WP_REST_Response(['error'=>'Fechas inválidas.'], 400);
        }
        $gcal    = new WTB_GCal();
        $tz_str  = wp_timezone_string();
        $tz      = new DateTimeZone( $tz_str );
        $start   = $req->get_param('start');
        $end     = $req->get_param('end');

        try {
            $dt_s = new DateTime( $start );
            $dt_e = new DateTime( $end );
            $dt_s->setTimezone( $tz );
            $dt_e->setTimezone( $tz );
            $gcal_start = $dt_s->format( DateTime::RFC3339 );
            $gcal_end   = $dt_e->format( DateTime::RFC3339 );
            $range_start = $dt_s->format('Y-m-d H:i:s');
            $range_end   = $dt_e->format('Y-m-d H:i:s');
        } catch ( Exception $ex ) {
            $gcal_start  = date('c', strtotime($start));
            $gcal_end    = date('c', strtotime($end));
            $range_start = date('Y-m-d H:i:s', strtotime($start));
            $range_end   = date('Y-m-d H:i:s', strtotime($end));
        }

        // ── Obtener de GCal ───────────────────────────────────────────────────
        $gcal_events = $gcal->list_events( $gcal_start, $gcal_end );

        // ── Obtener de BD local (fuente de verdad inmediata) ──────────────────
        global $wpdb;
        $table = $wpdb->prefix . WTB_Database::TABLE;
        $db_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT fecha_inicio, fecha_fin, gcal_event_id
             FROM {$table}
             WHERE estado = 'confirmada'
               AND fecha_inicio >= %s
               AND fecha_fin    <= %s",
            $range_start, $range_end
        ), ARRAY_A );

        // ── Fusionar: la BD tiene prioridad (actualización inmediata) ─────────
        $seen_ids = array_column( $gcal_events, 'id' );
        $events   = $gcal_events;

        foreach ( $db_rows as $row ) {
            // Evitar duplicados (si ya está en GCal, no añadir de nuevo)
            if ( ! empty($row['gcal_event_id']) && in_array($row['gcal_event_id'], $seen_ids, true) ) {
                continue;
            }
            // Convertir fecha local a RFC3339 con offset para FullCalendar
            try {
                $ds = new DateTime( $row['fecha_inicio'], $tz );
                $de = new DateTime( $row['fecha_fin'],    $tz );
                $events[] = [
                    'id'    => 'local_' . $row['gcal_event_id'],
                    'start' => $ds->format( DateTime::RFC3339 ),
                    'end'   => $de->format( DateTime::RFC3339 ),
                ];
            } catch ( Exception $ex ) {}
        }
        $label = wtb_opt('wtb_texto_ocupado', 'No disponible');
        $color = wtb_opt('wtb_color_ocupado', '#ef4444');
        $tz    = new DateTimeZone( wp_timezone_string() );
        $mapped = [];
        foreach ( $events as $e ) {
            try {
                $ds = new DateTime( $e['start'] ); $ds->setTimezone( $tz );
                $de = new DateTime( $e['end'] );   $de->setTimezone( $tz );
                $title = $label . ' · ' . $ds->format('H:i') . ' – ' . $de->format('H:i');
                // Retornar con offset de timezone para que el JS pueda parsear correctamente
                $start_local = $ds->format( 'Y-m-d\TH:i:sP' );
                $end_local   = $de->format( 'Y-m-d\TH:i:sP' );
            } catch ( Exception $ex ) {
                $title       = $label;
                $start_local = $e['start'];
                $end_local   = $e['end'];
            }
            $mapped[] = [
                'title'      => $title,
                'start'      => $start_local,
                'end'        => $end_local,
                'color'      => $color,
                'display'    => 'block',
                'editable'   => false,
                'classNames' => ['wtb-ocupado'],
            ];
        }
        $response = new WP_REST_Response( $mapped, 200 );
        // Instruir a LiteSpeed y otros caches a NO cachear este endpoint
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Pragma', 'no-cache');
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');
        return $response;
    }

    public function test_connection(): WP_REST_Response {
        check_ajax_referer('wp_rest');
        $gcal   = new WTB_GCal();
        $result = $gcal->test_connection();
        return new WP_REST_Response($result, $result['ok'] ? 200 : 400);
    }

    public function crear_reserva( WP_REST_Request $req ): WP_REST_Response {
        $b = json_decode($req->get_body(), true) ?: [];

        // ── Honeypot anti-bot: si viene relleno, es un bot ──────────────────────
        if ( ! empty($b['wtb_honeypot']) ) {
            // Silently reject bots — return 200 to not reveal the check
            return new WP_REST_Response(['success'=>false,'error'=>'Error de validación.'], 200);
        }

        // ── Verificar nonce (header WP REST estándar o body) ──────────────────
        $nonce_h = isset($_SERVER['HTTP_X_WP_NONCE']) ? sanitize_text_field($_SERVER['HTTP_X_WP_NONCE']) : '';
        $nonce_b = isset($b['nonce']) ? sanitize_text_field($b['nonce']) : '';
        $valid_nonce = ( ! empty($nonce_h) && wp_verify_nonce($nonce_h, 'wp_rest') )
                    || ( ! empty($nonce_b) && wp_verify_nonce($nonce_b, 'wp_rest') );
        if ( ! $valid_nonce )
            return $this->err('Sesión expirada. Recarga la página e inténtalo de nuevo.', 403);

        // ── Validar Content-Type ───────────────────────────────────────────────
        $content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
        if ( strpos($content_type, 'application/json') === false ) {
            return $this->err('Tipo de contenido no válido.', 415);
        }

        $nombre = sanitize_text_field($b['nombre'] ?? '');
        $email  = sanitize_email($b['email'] ?? '');
        $tel    = sanitize_text_field($b['telefono'] ?? '');
        $notas  = sanitize_textarea_field($b['notas'] ?? '');
        $ini    = sanitize_text_field($b['fecha_inicio'] ?? '');
        $fin    = sanitize_text_field($b['fecha_fin']    ?? '');

        if ( strlen($nombre)<2 )        return $this->err('El nombre es demasiado corto.',400);
        if ( ! is_email($email) )        return $this->err('El email no es válido.',400);
        // Parsear fecha local con timezone real del sitio
        $tz_string = get_option('timezone_string');
        if ( empty($tz_string) ) {
            $offset   = (float) get_option('gmt_offset', 0);
            $h        = (int) abs($offset);
            $m_       = (int) round((abs($offset) - $h) * 60);
            $tz_string = sprintf('%s%02d:%02d', $offset >= 0 ? '+' : '-', $h, $m_);
        }
        try {
            $tz     = new DateTimeZone( $tz_string );
            $dt_ini = new DateTime( $ini, $tz );
            $dt_fin = new DateTime( $fin, $tz );
        } catch ( Exception $e ) {
            return $this->err('Fecha inválida.', 400);
        }
        $now = new DateTime('now', $tz);
        if ( $dt_ini <= $now )        return $this->err('No puedes reservar en el pasado.', 400);
        if ( $dt_fin <= $dt_ini )     return $this->err('El fin debe ser posterior al inicio.', 400);
        // Usar strings formateados para consistencia
        $ini = $dt_ini->format('Y-m-d H:i:s');
        $fin = $dt_fin->format('Y-m-d H:i:s');

        // Use only REMOTE_ADDR — never trust X-Forwarded-For (spoofable)
        // On servers behind a trusted proxy, configure this via server/nginx level
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
        // Additional fingerprint with user agent to reduce collision risk
        $ip_key = md5($ip . (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''));
        $rk     = 'wtb_rl_' . $ip_key;
        $att = (int) get_transient($rk);
        if ( $att >= 10 ) return $this->err('Demasiados intentos. Espera unos minutos.',429);
        // Cap at 100 to prevent integer overflow on repeated attacks
        set_transient($rk, min(100, $att + 1), HOUR_IN_SECONDS);

        if ( ! WTB_Database::is_available($ini,$fin) )
            return $this->err('Esa franja ya está reservada. Elige otro horario.',409);

        $gcal    = new WTB_GCal();
        $gcal_id = $gcal->create_event(['nombre'=>$nombre,'email'=>$email,'telefono'=>$tel,'notas'=>$notas,'fecha_inicio'=>$ini,'fecha_fin'=>$fin]);

        $id = WTB_Database::insert(['nombre'=>$nombre,'email'=>$email,'telefono'=>$tel,'notas'=>$notas,
            'fecha_inicio'=>date('Y-m-d H:i:s',strtotime($ini)),
            'fecha_fin'   =>date('Y-m-d H:i:s',strtotime($fin)),
            'gcal_event_id'=>$gcal_id??'','origen'=>'web']);

        if ( ! $id ) {
            if ($gcal_id) $gcal->delete_event($gcal_id);
            return $this->err('Error interno. Inténtalo de nuevo.',500);
        }

        $this->send_email($nombre, $email, $ini);
        $this->send_whatsapp($nombre, $email, $tel, $ini, $fin);

        // Invalidar caché del plugin
        $gcal_for_cache = new WTB_GCal();
        $gcal_for_cache->bust_cache();

        // ── Purgar caches de terceros ──────────────────────────────────────────
        // LiteSpeed Cache
        if ( class_exists('\LiteSpeed\Purge') ) {
            do_action('litespeed_purge_all');
        }
        // WP Rocket
        if ( function_exists('rocket_clean_domain') ) {
            rocket_clean_domain();
        }
        // W3 Total Cache
        if ( function_exists('w3tc_flush_all') ) {
            w3tc_flush_all();
        }
        // WP Super Cache
        if ( function_exists('wp_cache_clear_cache') ) {
            wp_cache_clear_cache();
        }
        // SG Optimizer
        if ( class_exists('\SiteGround_Optimizer\Supercacher\Supercacher') ) {
            do_action('siteground_optimizer_flush_cache');
        }

        return new WP_REST_Response(['success'=>true,'mensaje'=>wtb_opt('wtb_msg_exito','¡Reserva confirmada!')],201);
    }

    private function send_email(string $nombre, string $email, string $ini): void {
        // Parsear fecha — $ini viene como 'YYYY-MM-DD HH:mm:ss'
        $ts    = strtotime($ini) ?: time();
        $fecha = date_i18n( get_option('date_format') . ' ' . get_option('time_format'), $ts );
        $site    = get_bloginfo('name');
        $headers = ['Content-Type: text/plain; charset=UTF-8'];

        // Email al CLIENTE
        $subject = str_replace( ['{site}','{nombre}'], [$site,$nombre],
            wtb_opt('wtb_email_asunto','[{site}] Confirmación de tu reserva') );
        $body = str_replace( ['{nombre}','{fecha}','{site}'], [$nombre,$fecha,$site],
            wtb_opt('wtb_email_cuerpo',"Hola {nombre},\n\nTu cita ha sido confirmada para el {fecha}.\n\nGracias,\n{site}") );
        wp_mail( $email, $subject, $body, $headers );

        // Email al ADMINISTRADOR
        $admin_email = get_option('admin_email');
        if ( ! empty($admin_email) && $admin_email !== $email ) {
            $subj_admin = '[' . $site . '] Nueva reserva: ' . $nombre;
            $body_admin = "Nueva reserva recibida en {$site}:\n\n"
                        . "Cliente:  {$nombre}\n"
                        . "Email:    {$email}\n"
                        . "Fecha:    {$fecha}\n\n"
                        . 'Gestionar: ' . admin_url('admin.php?page=wtb-bookings');
            wp_mail( $admin_email, $subj_admin, $body_admin, $headers );
        }
    }

    private function send_whatsapp(string $nombre, string $email, string $tel, string $ini, string $fin): void {
        $key    = wtb_opt('wtb_wa_callmebot_key');
        $owner  = wtb_opt('wtb_wa_owner_number');
        if ( empty($key) || empty($owner) ) return;

        $fecha  = date_i18n(get_option('date_format').' '.get_option('time_format'), strtotime($ini));
        $site   = get_bloginfo('name');

        // Mensaje al propietario
        $msg_owner = str_replace(
            ['{nombre}','{fecha}','{email}','{telefono}','{site}'],
            [$nombre,   $fecha,   $email,   $tel,        $site],
            wtb_opt('wtb_wa_msg_owner','Nueva reserva: {nombre} | {fecha} | {email} | Tel: {telefono}')
        );

        // Enviar al propietario via CallMeBot
        wp_remote_get( add_query_arg([
            'phone'   => rawurlencode($owner),
            'text'    => rawurlencode($msg_owner),
            'apikey'  => rawurlencode($key),
        ], 'https://api.callmebot.com/whatsapp.php'), ['timeout'=>10,'blocking'=>false] );

        // Mensaje al cliente (si tiene numero de WA)
        if ( ! empty($tel) ) {
            $tel_clean = preg_replace('/[^0-9+]/', '', $tel);
            $msg_client = str_replace(
                ['{nombre}','{fecha}','{site}'],
                [$nombre,   $fecha,   $site],
                wtb_opt('wtb_wa_msg_client','Hola {nombre}, tu cita ha sido confirmada para el {fecha}. Gracias!')
            );
            wp_remote_get( add_query_arg([
                'phone'   => rawurlencode($tel_clean),
                'text'    => rawurlencode($msg_client),
                'apikey'  => rawurlencode($key),
            ], 'https://api.callmebot.com/whatsapp.php'), ['timeout'=>10,'blocking'=>false] );
        }
    }

    private function err(string $msg, int $code): WP_REST_Response {
        return new WP_REST_Response(['success'=>false,'error'=>$msg],$code);
    }
}

/* ═══════════════════════════════════════════════════════════════════
   WTB_Shortcode
═══════════════════════════════════════════════════════════════════ */
class WTB_Shortcode {
    public function __construct() {
        add_shortcode('widetech_booking', [$this,'render']);
        add_action('wp_enqueue_scripts',  [$this,'enqueue']);
        add_action('wp_footer',           [$this,'enqueue']); // safety net for page builders
        add_action('wp_head',             [$this,'inject_css_vars']);
    }

    public function enqueue(): void {
        // Load on any singular page/post that contains the shortcode,
        // OR as a fallback check the queried object (handles page builders)
        if ( ! $this->page_has_shortcode() ) return;

        wp_enqueue_style('fullcalendar','https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css',[],        '6.1.11');
        wp_enqueue_script('fullcalendar','https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js', [],        '6.1.11', true);
        wp_enqueue_style( 'wtb-front',   WTB_URL.'assets/css/widetech-booking.css', ['fullcalendar'], WTB_VERSION);
        wp_enqueue_script('wtb-front',   WTB_URL.'assets/js/widetech-booking.js',   ['fullcalendar'], WTB_VERSION, true);

        $slot_min = (int) wtb_opt('wtb_slot_duration','60');
        wp_localize_script('wtb-front','WTB',[
            'api'             => rest_url('wtb/v1/'),
            'nonce'           => wp_create_nonce('wp_rest'),
            'timezone'        => wp_timezone_string(),
            'slot_duration'   => $slot_min,
            'hora_inicio'     => wtb_opt('wtb_hora_inicio','09:00'),
            'hora_fin'        => wtb_opt('wtb_hora_fin','19:00'),
            'dias'            => array_map('intval', json_decode(wtb_opt('wtb_dias','[1,2,3,4,5]'), true) ?: [1,2,3,4,5]),
            'vista'           => wtb_opt('wtb_vista_inicial','timeGridWeek'),
            'dias_max_futuro' => (int) wtb_opt('wtb_dias_max_futuro','60'),
            'titulo_modal'    => wtb_opt('wtb_titulo_modal','Solicitar cita'),
            'btn_texto'       => wtb_opt('wtb_btn_texto','Confirmar reserva'),
            'campo_tel'       => wtb_opt('wtb_campo_tel','1'),
            'campo_notas'     => wtb_opt('wtb_campo_notas','1'),
            'tel_required'    => wtb_opt('wtb_tel_required','0'),
            'label_nombre'    => wtb_opt('wtb_label_nombre','Nombre completo'),
            'label_email'     => wtb_opt('wtb_label_email','Correo electrónico'),
            'label_tel'       => wtb_opt('wtb_label_tel','Teléfono'),
            'label_notas'     => wtb_opt('wtb_label_notas','Notas'),
            'ph_nombre'       => wtb_opt('wtb_ph_nombre','Tu nombre completo'),
            'ph_email'        => wtb_opt('wtb_ph_email','tu@email.com'),
            'ph_tel'          => wtb_opt('wtb_ph_tel','+34 600 000 000'),
            'open_btn_label'  => wtb_opt('wtb_open_btn_label','Reservar cita'),
            'lock_icon_char'  => (function() {
                $custom = wtb_opt('wtb_lock_icon_custom','');
                if (!empty($custom)) return esc_html($custom);
                $char = wtb_opt('wtb_lock_icon_char','');
                return esc_html($char); // sanitize before JS output
            })(),
            'ph_notas'        => wtb_opt('wtb_ph_notas','¿Algo que debamos saber?'),
        ]);
    }

    /** Genera CSS variables dinámicas desde las opciones del admin */
    public function inject_css_vars(): void {
        global $post;
        if ( ! is_a($post,'WP_Post') ) return;
        if ( ! has_shortcode($post->post_content,'widetech_booking') && ! did_action('wtb_shortcode_rendered') ) return;

        $theme = wtb_opt('wtb_theme', 'light');

        // Para light y dark, solo inyectar el color primario del botón (heredado del tema)
        // Para custom, inyectar todas las variables configuradas
        if ( $theme !== 'custom' ) {
            printf('<style id="wtb-vars">
                #wtb-open-btn { background: %s !important; color: %s !important; }
                #wtb-open-btn:hover { background: %s !important; }
            </style>',
                esc_attr(wtb_opt('wtb_color_primario','#4f46e5')),
                esc_attr(wtb_opt('wtb_color_texto_btn','#ffffff')),
                esc_attr(wtb_opt('wtb_color_hover','#4338ca'))
            );
            return;
        }

        // Tema CUSTOM — inyectar todas las CSS vars
        $r   = (int) wtb_opt('wtb_radio_modal','14');
        $rb  = (int) wtb_opt('wtb_radio_btn','8');
        $cr  = (int) wtb_opt('wtb_cal_radius','12');
        $sh  = wtb_opt('wtb_sombra_modal','1') === '1' ? '0 24px 60px rgba(0,0,0,.18)' : 'none';
        $ff  = esc_attr(wtb_opt('wtb_font_family','inherit'));
        $fst = esc_attr(wtb_opt('wtb_font_size_titulo','1.15'));
        $fsl = esc_attr(wtb_opt('wtb_font_size_label','0.83'));
        $fsi = esc_attr(wtb_opt('wtb_font_size_input','0.93'));
        $fsb = esc_attr(wtb_opt('wtb_font_size_btn','0.97'));
        $fwt = esc_attr(wtb_opt('wtb_font_weight_titulo','700'));
        $fwb = esc_attr(wtb_opt('wtb_font_weight_btn','700'));
        $fwl = esc_attr(wtb_opt('wtb_font_weight_label','600'));

        printf('<style id="wtb-vars">:root, #wtb-box[data-theme="custom"], #wtb-wrap[data-theme="custom"]{
            --wtb-primary:%s; --wtb-primary-h:%s; --wtb-btn-text:%s; --wtb-ocupado:%s;
            --wtb-r-modal:%dpx; --wtb-r-btn:%dpx; --wtb-shadow:%s;
            --wtb-font:%s; --wtb-fs-titulo:%srem; --wtb-fs-label:%srem;
            --wtb-fs-input:%srem; --wtb-fs-btn:%srem;
            --wtb-fw-titulo:%s; --wtb-fw-btn:%s; --wtb-fw-label:%s;
            --wtb-cal-bg:%s; --wtb-cal-hbg:%s; --wtb-cal-htx:%s;
            --wtb-cal-bor:%s; --wtb-cal-today-bg:%s; --wtb-cal-today-c:%s;
            --wtb-cal-now:%s; --wtb-cal-hover:%s; --wtb-cal-txt:%s; --wtb-cal-r:%dpx;
        }</style>',
            esc_attr(wtb_opt('wtb_color_primario','#4f46e5')),
            esc_attr(wtb_opt('wtb_color_hover','#4338ca')),
            esc_attr(wtb_opt('wtb_color_texto_btn','#ffffff')),
            esc_attr(wtb_opt('wtb_color_ocupado','#ef4444')),
            $r, $rb, $sh, $ff, $fst, $fsl, $fsi, $fsb, $fwt, $fwb, $fwl,
            esc_attr(wtb_opt('wtb_cal_bg','#ffffff')),
            esc_attr(wtb_opt('wtb_cal_header_bg','#f8f9fc')),
            esc_attr(wtb_opt('wtb_cal_header_text','#1e293b')),
            esc_attr(wtb_opt('wtb_cal_border','#e2e8f0')),
            esc_attr(wtb_opt('wtb_cal_today_bg','#fff8e1')),
            esc_attr(wtb_opt('wtb_cal_today_border','#f59e0b')),
            esc_attr(wtb_opt('wtb_cal_now_line','#ef4444')),
            esc_attr(wtb_opt('wtb_cal_slot_hover','#f1f0ff')),
            esc_attr(wtb_opt('wtb_cal_text','#334155')),
            $cr
        );
    }

    public function render( $atts ): string {
        $gcal      = new WTB_GCal();
        $connected = $gcal->is_connected();
        $cfg_url   = admin_url('admin.php?page=wtb-settings&tab=google');

        do_action('wtb_shortcode_rendered');
        $hint_text  = wtb_opt('wtb_hint_text',  '👆 Haz clic en el calendario o en el botón para reservar tu cita.');
        $btn_label  = wtb_opt('wtb_open_btn_label', '📅 Reservar cita');
        ob_start(); ?>
        <div id="wtb-wrap" data-theme="<?= esc_attr(wtb_opt('wtb_theme','light')) ?>">
        <?php if ( $hint_text ): ?>
        <div id="wtb-hint-bar"><span><?= esc_html($hint_text) ?></span></div>
        <?php endif; ?>
        <?php if ( ! $connected && current_user_can('manage_options') ): ?>
        <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:14px 18px;margin-bottom:16px;font-family:sans-serif;font-size:.9rem;">
            &#9888;&#65039; <strong>WIdeTech Booking:</strong> Google Calendar no est&#225; conectado.
            El calendario se mostrar&#225; vac&#237;o hasta que lo configures.
            <a href="<?= esc_url($cfg_url) ?>" style="margin-left:8px;font-weight:700;color:#856404;">
                &#8594; Ir a Ajustes
            </a>
            <em style="display:block;margin-top:4px;color:#856404;font-size:.8rem;">
                Este aviso solo lo ves t&#250; como administrador.
            </em>
        </div>
        <?php endif; ?>
            <div id="wtb-calendar"></div>
            <!-- BOTÓN ARRIBA (si está configurado así) -->
            <?php $btn_pos = wtb_opt('wtb_btn_position','bottom'); $btn_label = wtb_opt('wtb_open_btn_label','📅 Reservar cita'); ?>
            <?php if ($btn_pos === 'top'): ?>
            <div id="wtb-btn-wrap" class="wtb-btn-top">
                <button id="wtb-open-btn" type="button"><?= esc_html($btn_label) ?></button>
            </div>
            <?php endif; ?>

            <!-- Calendario -->
            <div id="wtb-calendar"></div>

            <!-- BOTÓN ABAJO (por defecto) -->
            <?php if ($btn_pos === 'bottom'): ?>
            <div id="wtb-btn-wrap" class="wtb-btn-bottom">
                <button id="wtb-open-btn" type="button"><?= esc_html($btn_label) ?></button>
            </div>
            <?php endif; ?>

            <!-- Modal -->
            <div id="wtb-modal" role="dialog" aria-modal="true" style="display:none;">
                <div id="wtb-box" data-theme="<?= esc_attr(wtb_opt('wtb_theme','light')) ?>">
                    <button id="wtb-close" aria-label="Cerrar">&times;</button>
                    <h3 id="wtb-modal-title"></h3>

                    <div id="wtb-modal-body">
                        <!-- Columna izquierda: fecha + horas -->
                        <div id="wtb-col-left">
                            <div class="wtb-field-group">
                                <label class="wtb-group-label" for="wtb-date-picker">
                                <svg class="wtb-lbl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                                <?= esc_html( wtb_opt('wtb_icon_label_fecha', 'Fecha') ) ?>
                            </label>
                                <input type="date" id="wtb-date-picker" class="wtb-date-input">
                            </div>
                            <div class="wtb-field-group">
                                <label class="wtb-group-label">
                                <svg class="wtb-lbl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                <?= esc_html( wtb_opt('wtb_icon_label_hora', 'Hora disponible') ) ?>
                            </label>
                                <div id="wtb-time-grid"></div>
                            </div>
                            <div id="wtb-slot-info" class="wtb-slot-info-empty"></div>
                        </div>

                        <!-- Columna derecha: datos -->
                        <div id="wtb-col-right">
                            <!-- Honeypot: bots fill this, humans don't see it -->
                            <div style="position:absolute;left:-9999px;opacity:0;pointer-events:none;" aria-hidden="true">
                                <input type="text" name="wtb_honeypot" tabindex="-1" autocomplete="off">
                            </div>
                            <div class="wtb-f" id="wtb-f-nombre">
                                <label id="wtb-lbl-nombre" for="wtb-nombre"></label>
                                <input id="wtb-nombre" name="nombre" type="text" maxlength="100" autocomplete="name">
                            </div>
                            <div class="wtb-f" id="wtb-f-email">
                                <label id="wtb-lbl-email" for="wtb-email"></label>
                                <input id="wtb-email" name="email" type="email" maxlength="100" autocomplete="email">
                            </div>
                            <div class="wtb-f" id="wtb-f-tel">
                                <label id="wtb-lbl-tel" for="wtb-tel"></label>
                                <input id="wtb-tel" name="telefono" type="tel" maxlength="30" autocomplete="tel">
                            </div>
                            <div class="wtb-f" id="wtb-f-whatsapp">
                                <label id="wtb-lbl-whatsapp" for="wtb-whatsapp">WhatsApp (opcional)</label>
                                <input id="wtb-whatsapp" name="whatsapp" type="tel" maxlength="30" placeholder="+34 600 000 000">
                            </div>
                            <div class="wtb-f" id="wtb-f-notas">
                                <label id="wtb-lbl-notas" for="wtb-notas"></label>
                                <textarea id="wtb-notas" name="notas" rows="2" maxlength="500"></textarea>
                            </div>
                        </div>
                    </div>

                    <form id="wtb-form" novalidate>
                        <button type="submit" id="wtb-submit"></button>
                        <p id="wtb-msg" role="alert"></p>
                    </form>
                </div>
            </div>

                <?php return ob_get_clean();
    }

    /** Checks if current page uses our shortcode */
    private function page_has_shortcode(): bool {
        global $post;
        if ( did_action('wtb_shortcode_rendered') ) return true;
        if ( is_a($post,'WP_Post') && has_shortcode($post->post_content,'widetech_booking') ) return true;
        $obj = get_queried_object();
        if ( is_a($obj,'WP_Post') && has_shortcode($obj->post_content,'widetech_booking') ) return true;
        return false;
    }

}
/* ═══════════════════════════════════════════════════════════════════
   WTB_Sync
═══════════════════════════════════════════════════════════════════ */
class WTB_Sync {
    public function __construct() {
        add_filter('cron_schedules',[$this,'add_interval']);
        if ( ! wp_next_scheduled('wtb_sync_cron') )
            wp_schedule_event(time(),'wtb_5min','wtb_sync_cron');
        add_action('wtb_sync_cron',[$this,'run']);
    }
    public function add_interval(array $s): array {
        $s['wtb_5min']=['interval'=>300,'display'=>'Cada 5 min (WTB)'];
        return $s;
    }
    public function run(): void {
        $gcal = new WTB_GCal();
        if ( ! $gcal->is_connected() ) return;
        global $wpdb;
        $t      = $wpdb->prefix . WTB_Database::TABLE;
        $now    = date('c');
        $future = date('c', strtotime('+14 days'));
        $evs    = $gcal->list_events($now,$future);
        $ids    = array_column($evs,'id');
        $bd     = $wpdb->get_results("SELECT id,gcal_event_id FROM {$t} WHERE estado='confirmada' AND gcal_event_id!='' AND fecha_inicio>=NOW()",ARRAY_A);
        foreach($bd as $r) {
            if ( ! in_array($r['gcal_event_id'],$ids,true) )
                $wpdb->update($t,['estado'=>'cancelada'],['id'=>$r['id']],['%s'],['%d']);
        }
        $bd_ids = array_column($bd,'gcal_event_id');
        foreach($evs as $ev) {
            if ( in_array($ev['id'],$bd_ids,true) ) continue;
            if ( (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE gcal_event_id=%s",$ev['id'])) ) continue;
            WTB_Database::insert(['gcal_event_id'=>$ev['id'],'nombre'=>'Bloqueado','email'=>'',
                'fecha_inicio'=>date('Y-m-d H:i:s',strtotime($ev['start'])),
                'fecha_fin'   =>date('Y-m-d H:i:s',strtotime($ev['end'])),
                'origen'=>'gcal']);
        }
    }
}
