# Security Policy — WIdeTech Booking

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.0.x   | ✅ Yes    |
| < 2.0   | ❌ No     |

## Reporting a Vulnerability

Please **do NOT** report security vulnerabilities via GitHub Issues.

Email: security@widetecsolutions.com

Include:
- Plugin version
- WordPress version
- PHP version
- Steps to reproduce
- Potential impact

We respond within 48 hours and publish a fix within 7 days for critical issues.

## Security Features

- All inputs sanitized with WordPress core functions
- Nonce verification on all admin forms (CSRF protection)
- Honeypot field to block automated spam submissions
- Rate limiting: max 10 booking attempts per IP per hour
- `wp_safe_redirect()` with whitelisted tabs (open redirect prevention)
- JSON storage instead of PHP serialize (object injection prevention)
- OAuth token stored with autoload=false (not loaded on every request)
- `exit()` after every redirect
- Input length validation on all REST endpoints
- Date range validation on public endpoints (max 100 days)
- Data fully purged on plugin uninstall (GDPR compliant)
