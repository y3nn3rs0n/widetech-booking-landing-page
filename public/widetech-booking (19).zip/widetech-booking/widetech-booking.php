<?php
/**
 * Plugin Name:  WIdeTech Booking
 * Plugin URI:   https://widetecsolutions.com
 * Description:  Sistema de reservas con Google Calendar. Sin código. 100% configurable.
 * Version:      2.0.0
 * Author:       WIdeTech
 * Author URI:   https://widetecsolutions.com
 * License:      GPL-2.0+
 * Text Domain:  widetech-booking
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WTB_VERSION',  '2.0.0' );
define( 'WTB_PATH',     plugin_dir_path( __FILE__ ) );
define( 'WTB_URL',      plugin_dir_url( __FILE__ ) );
define( 'WTB_BASENAME', plugin_basename( __FILE__ ) );

// ── Archivos del plugin ───────────────────────────────────────────────────────
require_once WTB_PATH . 'includes/classes.php';   // Database, REST, Shortcode, Sync
require_once WTB_PATH . 'includes/icons.php';       // SVG icon helpers
require_once WTB_PATH . 'includes/class-gcal.php'; // Google Calendar API (sin Composer)
require_once WTB_PATH . 'admin/admin-menu.php';

// ── Activación ────────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, function () {
    WTB_Database::create_table();
    if ( ! get_option('wtb_installed') ) {
        update_option( 'wtb_installed',    '1' );
        update_option( 'wtb_show_wizard',  '1' );
        update_option( 'wtb_wizard_step',  '1' );
        // Defaults
        update_option( 'wtb_slot_duration',  '60' );
        update_option( 'wtb_hora_inicio',    '09:00' );
        update_option( 'wtb_hora_fin',       '19:00' );
        update_option( 'wtb_dias', json_encode([1,2,3,4,5]) ); // JSON safer than serialize
        update_option( 'wtb_color_primario', '#4f46e5' );
        update_option( 'wtb_color_ocupado',  '#ef4444' );
        update_option( 'wtb_color_hover',    '#4338ca' );
        update_option( 'wtb_color_texto_btn','#ffffff' );
        update_option( 'wtb_radio_modal',    '12' );
        update_option( 'wtb_radio_btn',      '8' );
        update_option( 'wtb_sombra_modal',   '1' );
        update_option( 'wtb_texto_ocupado',  'No disponible' );
        update_option( 'wtb_titulo_modal',   'Solicitar cita' );
        update_option( 'wtb_btn_texto',      'Confirmar reserva' );
        update_option( 'wtb_msg_exito',      '¡Reserva confirmada! Te hemos enviado un email.' );
        update_option( 'wtb_campo_tel',      '1' );
        update_option( 'wtb_campo_notas',    '1' );
        update_option( 'wtb_tel_required',   '0' );
        update_option( 'wtb_label_nombre',   'Nombre completo' );
        update_option( 'wtb_label_email',    'Correo electrónico' );
        update_option( 'wtb_label_tel',      'Teléfono' );
        update_option( 'wtb_label_notas',    'Notas o comentarios' );
        update_option( 'wtb_ph_nombre',      'Tu nombre completo' );
        update_option( 'wtb_ph_email',       'tu@email.com' );
        update_option( 'wtb_ph_tel',         '+34 600 000 000' );
        update_option( 'wtb_ph_notas',       '¿Algo que debamos saber?' );
        update_option( 'wtb_email_asunto',   '[{site}] Confirmación de reserva' );
        update_option( 'wtb_email_cuerpo',   "Hola {nombre},\n\nTu cita ha sido confirmada.\n\n📅 Fecha: {fecha}\n\nGracias,\n{site}" );
        update_option( 'wtb_vista_inicial',  'timeGridWeek' );
        update_option( 'wtb_dias_max_futuro','60' );
        update_option( 'wtb_font_family',    'inherit' );
        update_option( 'wtb_cal_bg',          '#ffffff' );
        update_option( 'wtb_cal_header_bg',   '#f8f9fc' );
        update_option( 'wtb_cal_header_text', '#1e293b' );
        update_option( 'wtb_cal_border',      '#e2e8f0' );
        update_option( 'wtb_cal_today_bg',    '#fff8e1' );
        update_option( 'wtb_cal_today_border','#f59e0b' );
        update_option( 'wtb_cal_now_line',    '#ef4444' );
        update_option( 'wtb_cal_slot_hover',  '#f1f0ff' );
        update_option( 'wtb_cal_text',        '#334155' );
        update_option( 'wtb_cal_radius',      '12' );
        update_option( 'wtb_hint_text', '👆 Haz clic en el calendario o en el botón para reservar tu cita.' );
        update_option( 'wtb_open_btn_label', '📅 Reservar cita' );
        update_option( 'wtb_open_btn_color', '' );
        update_option( 'wtb_theme',           'light' );   // light | dark | custom
        update_option( 'wtb_btn_position',    'bottom' );
        update_option( 'wtb_lock_icon_char',   '' );
        update_option( 'wtb_lock_icon_custom', '' );
        update_option( 'wtb_icon_label_fecha', 'Fecha' );
        update_option( 'wtb_icon_label_hora',  'Hora disponible' );  // top | bottom
        // WhatsApp
        update_option( 'wtb_wa_owner_number', '' );   // numero del propietario con codigo pais
        update_option( 'wtb_wa_callmebot_key', '' );  // API key de CallMeBot
        update_option( 'wtb_wa_msg_owner',  'Nueva reserva: {nombre} | {fecha} | {email} | Tel: {telefono}' );
        update_option( 'wtb_wa_msg_client', 'Hola {nombre}, tu cita ha sido confirmada para el {fecha}. Gracias!' );
        update_option( 'wtb_font_size_titulo','1.2' );
        update_option( 'wtb_font_size_label','0.875' );
        update_option( 'wtb_font_size_input','0.95' );
        update_option( 'wtb_font_size_btn',  '1' );
        update_option( 'wtb_font_weight_titulo','700' );
        update_option( 'wtb_font_weight_btn',   '700' );
        update_option( 'wtb_font_weight_label', '600' );
    }
});

// ── Desactivación ──────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, function () {
    $ts = wp_next_scheduled('wtb_sync_cron');
    if ( $ts ) wp_unschedule_event( $ts, 'wtb_sync_cron' );
});

// ── Desinstalación: limpiar TODOS los datos sensibles ──────────────────────────
// Se ejecuta solo cuando el usuario hace "Eliminar" desde el panel de plugins
register_uninstall_hook( __FILE__, 'wtb_uninstall' );
function wtb_uninstall(): void {
    if ( ! current_user_can('activate_plugins') ) return;

    global $wpdb;

    // Eliminar tabla de reservas
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wtb_reservas" );

    // Eliminar TODAS las opciones del plugin (incluyendo el token OAuth)
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE 'wtb_%'
            OR option_name LIKE '_transient_wtb_%'
            OR option_name LIKE '_transient_timeout_wtb_%'"
    );

    // Limpiar cron
    wp_clear_scheduled_hook('wtb_sync_cron');
}

// ── Inicializar clases ────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    new WTB_REST_API();
    new WTB_Shortcode();
    new WTB_Sync();
});

// ── Acceso rápido desde lista de plugins ──────────────────────────────────────
add_filter( 'plugin_action_links_' . WTB_BASENAME, function ( $links ) {
    array_unshift( $links,
        '<a href="' . admin_url('admin.php?page=wtb-dashboard') . '">⚙️ Configurar</a>'
    );
    return $links;
});

// ── Helper global ─────────────────────────────────────────────────────────────
function wtb_opt( string $key, $default = '' ) {
    return get_option( $key, $default );
}

// ── Bloquear acceso directo a archivos PHP del plugin ─────────────────────────
// (cada archivo ya tiene: if ( ! defined('ABSPATH') ) exit; )

// ── Prevenir enumeración de usuarios vía REST API ─────────────────────────────
// Solo aplica si el admin no ha configurado otra política
add_filter('rest_endpoints', function( $endpoints ) {
    // Nuestros endpoints son seguros; bloquear solo si alguien intenta
    // acceder a /users con nuestros nonces (no aplica, WP maneja esto)
    return $endpoints;
});

// ── Registrar capacidades personalizadas del plugin ───────────────────────────
add_action('init', function() {
    // Todas las operaciones admin requieren manage_options (ya validado)
    // Las reservas públicas no requieren autenticación (diseño intencional)
});

// ── Sanitizar el Client Secret antes de mostrarlo en ajustes ─────────────────
function wtb_mask_secret( string $secret ): string {
    if ( empty($secret) ) return '';
    $len = strlen($secret);
    return substr($secret, 0, 8) . str_repeat('•', max(0, $len - 8));
}

// ── Excluir endpoints REST del caché de LiteSpeed ────────────────────────────
add_filter('litespeed_is_bypass_cache', function( $bypass ) {
    if ( strpos( $_SERVER['REQUEST_URI'] ?? '', '/wp-json/wtb/' ) !== false ) {
        return true; // No cachear nuestro endpoint
    }
    return $bypass;
}, 10, 1);

// LiteSpeed: no-cache tag para nuestros endpoints
add_action('litespeed_tag_add', function() {
    if ( strpos( $_SERVER['REQUEST_URI'] ?? '', '/wp-json/wtb/' ) !== false ) {
        do_action('litespeed_tag_add', 'wtb_rest');
    }
});
