<?php
if ( ! defined('ABSPATH') ) exit;

/* ══════════════════════════════════════════════════════════════
   REGISTRO DE MENÚ EN EL SIDEBAR DE WORDPRESS
══════════════════════════════════════════════════════════════ */
add_action('admin_menu', function() {
    add_menu_page(
        'WIdeTech Booking',
        'WTB Booking',
        'manage_options',
        'wtb-dashboard',
        'wtb_page_dashboard',
        'dashicons-calendar-alt',
        30
    );
    add_submenu_page('wtb-dashboard','Dashboard','<?= wtb_icon("dashboard") ?> Dashboard',           'manage_options','wtb-dashboard',   'wtb_page_dashboard');
    add_submenu_page('wtb-dashboard','Asistente', '<?= wtb_icon("wizard") ?> Asistente','manage_options','wtb-wizard',      'wtb_page_wizard');
    add_submenu_page('wtb-dashboard','Ajustes',   '<?= wtb_icon("settings") ?> Ajustes',            'manage_options','wtb-settings',    'wtb_page_settings');
    add_submenu_page('wtb-dashboard','Reservas',  '<?= wtb_icon("bookings") ?> Reservas',           'manage_options','wtb-bookings',    'wtb_page_bookings');
    // Página oculta OAuth callback
    add_submenu_page('wtb-dashboard','','','manage_options','wtb-oauth-callback','wtb_page_oauth_callback');
});

/* ══════════════════════════════════════════════════════════════
   ENQUEUE ADMIN ASSETS
══════════════════════════════════════════════════════════════ */
add_action('admin_enqueue_scripts', function($hook) {
    if ( strpos($hook,'wtb-') === false && strpos($hook,'page_wtb') === false ) return;
    wp_enqueue_style( 'wtb-admin', WTB_URL.'assets/css/wtb-admin.css', [], WTB_VERSION);
    wp_enqueue_script('wtb-admin', WTB_URL.'assets/js/wtb-admin.js',   ['jquery','wp-color-picker'], WTB_VERSION, true);
    wp_enqueue_style('wp-color-picker');
    wp_localize_script('wtb-admin','WTB_Admin',[
        'api'   => rest_url('wtb/v1/'),
        'nonce' => wp_create_nonce('wp_rest'),
    ]);
});

/* ══════════════════════════════════════════════════════════════
   BANNER "IR AL ASISTENTE" si aún no se ha configurado
══════════════════════════════════════════════════════════════ */
add_action('admin_notices', function() {
    if ( get_option('wtb_show_wizard') === '1' && ! get_option('wtb_gcal_client_id') ) {
        $url = admin_url('admin.php?page=wtb-wizard');
        echo "<div class='notice notice-info' style='padding:12px 16px;'>
            <strong>🚀 WIdeTech Booking:</strong> ¡Bienvenido! Completa el
            <a href='{$url}' style='font-weight:700;'>Asistente de configuración</a>
            para poner en marcha tu sistema de reservas en 5 minutos.
            <a href='" . wp_nonce_url(admin_url('admin.php?page=wtb-wizard&wtb_dismiss=1'), 'wtb_dismiss_wizard') . "' style='float:right;color:#999;'>Cerrar</a>
        </div>";
    }
});
add_action('admin_init', function() {
    if ( isset($_GET['wtb_dismiss']) && current_user_can('manage_options')
         && check_admin_referer('wtb_dismiss_wizard') ) {
        update_option('wtb_show_wizard','0');
    }
});

/* ══════════════════════════════════════════════════════════════
   GUARDAR AJUSTES (POST handler)
══════════════════════════════════════════════════════════════ */
add_action('admin_init', function() {
    if ( ! isset($_POST['wtb_save_settings']) ) return;
    if ( ! check_admin_referer('wtb_settings') ) return;
    if ( ! current_user_can('manage_options') ) return;

    $fields = [
        'wtb_gcal_client_id'   => 'sanitize_text_field',
        'wtb_gcal_client_secret'=> 'sanitize_text_field',
        'wtb_gcal_calendar_id' => 'sanitize_text_field',
        'wtb_slot_duration'    => 'absint',
        'wtb_hora_inicio'      => 'sanitize_text_field',
        'wtb_hora_fin'         => 'sanitize_text_field',
        'wtb_dias_max_futuro'  => 'absint',
        'wtb_vista_inicial'    => 'sanitize_text_field',
        'wtb_color_primario'   => 'sanitize_hex_color',
        'wtb_color_hover'      => 'sanitize_hex_color',
        'wtb_color_ocupado'    => 'sanitize_hex_color',
        'wtb_color_texto_btn'  => 'sanitize_hex_color',
        'wtb_radio_modal'      => 'absint',
        'wtb_radio_btn'        => 'absint',
        'wtb_sombra_modal'     => 'sanitize_text_field',
        'wtb_texto_ocupado'    => 'sanitize_text_field',
        'wtb_titulo_modal'     => 'sanitize_text_field',
        'wtb_btn_texto'        => 'sanitize_text_field',
        'wtb_msg_exito'        => 'sanitize_text_field',
        'wtb_campo_tel'        => 'sanitize_text_field',
        'wtb_campo_notas'      => 'sanitize_text_field',
        'wtb_tel_required'     => 'sanitize_text_field',
        'wtb_label_nombre'     => 'sanitize_text_field',
        'wtb_label_email'      => 'sanitize_text_field',
        'wtb_label_tel'        => 'sanitize_text_field',
        'wtb_label_notas'      => 'sanitize_text_field',
        'wtb_ph_nombre'        => 'sanitize_text_field',
        'wtb_ph_email'         => 'sanitize_text_field',
        'wtb_ph_tel'           => 'sanitize_text_field',
        'wtb_ph_notas'         => 'sanitize_text_field',
        'wtb_email_asunto'     => 'sanitize_text_field',
        'wtb_email_cuerpo'     => 'sanitize_textarea_field',
        'wtb_font_family'      => 'sanitize_text_field',
        'wtb_font_size_titulo' => 'sanitize_text_field',
        'wtb_font_size_label'  => 'sanitize_text_field',
        'wtb_font_size_input'  => 'sanitize_text_field',
        'wtb_font_size_btn'    => 'sanitize_text_field',
        'wtb_font_weight_titulo'=> 'sanitize_text_field',
        'wtb_font_weight_btn'  => 'sanitize_text_field',
        'wtb_font_weight_label'=> 'sanitize_text_field',
        'wtb_cal_bg'           => 'sanitize_hex_color',
        'wtb_cal_header_bg'    => 'sanitize_hex_color',
        'wtb_cal_header_text'  => 'sanitize_hex_color',
        'wtb_cal_border'       => 'sanitize_hex_color',
        'wtb_cal_today_bg'     => 'sanitize_hex_color',
        'wtb_cal_today_border' => 'sanitize_hex_color',
        'wtb_cal_now_line'     => 'sanitize_hex_color',
        'wtb_cal_slot_hover'   => 'sanitize_hex_color',
        'wtb_cal_text'         => 'sanitize_hex_color',
        'wtb_cal_radius'       => 'absint',
        'wtb_hint_text'        => 'sanitize_text_field',
        'wtb_open_btn_label'   => 'sanitize_text_field',
        'wtb_open_btn_color'   => 'sanitize_hex_color',
        'wtb_lock_icon_char'   => 'sanitize_text_field',
        'wtb_lock_icon_custom' => 'sanitize_text_field',
        'wtb_icon_label_fecha' => 'sanitize_text_field',
        'wtb_icon_label_hora'  => 'sanitize_text_field',
        'wtb_theme'            => 'sanitize_text_field',
        'wtb_btn_position'     => 'sanitize_text_field',
        'wtb_wa_owner_number'  => 'sanitize_text_field',
        'wtb_wa_callmebot_key' => 'sanitize_text_field',
        'wtb_wa_msg_owner'     => 'sanitize_textarea_field',
        'wtb_wa_msg_client'    => 'sanitize_textarea_field',
    ];

    foreach ( $fields as $key => $fn ) {
        if ( isset($_POST[$key]) ) {
            $val = $fn === 'absint' ? absint($_POST[$key]) : $fn($_POST[$key]);
            update_option($key, $val);
        }
    }
    // Checkboxes (días laborables, campos opcionales)
    // Use JSON instead of serialize — prevents PHP object injection attacks
    update_option('wtb_dias', json_encode( array_map('absint', isset($_POST['wtb_dias']) ? (array)$_POST['wtb_dias'] : [] ) ));
    update_option('wtb_campo_tel',    isset($_POST['wtb_campo_tel'])    ? '1' : '0');
    update_option('wtb_campo_notas',  isset($_POST['wtb_campo_notas'])  ? '1' : '0');
    update_option('wtb_tel_required', isset($_POST['wtb_tel_required']) ? '1' : '0');
    update_option('wtb_sombra_modal', isset($_POST['wtb_sombra_modal']) ? '1' : '0');

    // Sanitize tab: whitelist-only approach prevents open redirect
    $allowed_tabs = ['google','horarios','diseno','formulario','emails','whatsapp'];
    $tab_raw      = sanitize_key( $_POST['wtb_current_tab'] ?? 'google' );
    $safe_tab     = in_array($tab_raw, $allowed_tabs, true) ? $tab_raw : 'google';

    if ( isset($_POST['wtb_wizard_step']) && $_POST['wtb_wizard_step'] === '4' ) {
        wp_safe_redirect( admin_url('admin.php?page=wtb-wizard&step=5') ); exit;
    } else {
        wp_safe_redirect( admin_url('admin.php?page=wtb-settings&saved=1&tab=' . $safe_tab) ); exit;
    }
});

/* ══════════════════════════════════════════════════════════════
   PAGE: DASHBOARD
══════════════════════════════════════════════════════════════ */
function wtb_page_dashboard(): void {
    $gcal      = new WTB_GCal();
    $connected = $gcal->is_connected();
    $total     = WTB_Database::count();
    $recientes = WTB_Database::get_all(5,0);
    ?>
    <div class="wrap wtb-wrap">
        <div class="wtb-header">
            <div class="wtb-header-logo"><?= wtb_icon("calendar",'',22) ?> WIdeTech Booking</div>
            <div class="wtb-header-version">v<?= WTB_VERSION ?></div>
        </div>

        <!-- Tarjetas de estado -->
        <div class="wtb-cards">
            <div class="wtb-card wtb-card-stat">
                <div class="wtb-card-icon">📋</div>
                <div class="wtb-card-body">
                    <div class="wtb-card-num"><?= $total ?></div>
                    <div class="wtb-card-label">Reservas totales</div>
                </div>
            </div>
            <div class="wtb-card wtb-card-stat <?= $connected ? 'wtb-ok' : 'wtb-warn' ?>">
                <div class="wtb-card-icon"><?= $connected ? '✅' : '⚠️' ?></div>
                <div class="wtb-card-body">
                    <div class="wtb-card-num"><?= $connected ? 'Conectado' : 'Sin conectar' ?></div>
                    <div class="wtb-card-label">Google Calendar</div>
                </div>
            </div>
            <div class="wtb-card wtb-card-stat">
                <div class="wtb-card-icon">⏱️</div>
                <div class="wtb-card-body">
                    <div class="wtb-card-num"><?= wtb_opt('wtb_slot_duration','60') ?> min</div>
                    <div class="wtb-card-label">Duración de cita</div>
                </div>
            </div>
            <div class="wtb-card wtb-card-stat">
                <div class="wtb-card-icon"></div>
                <div class="wtb-card-body">
                    <div class="wtb-card-num"><?= wtb_opt('wtb_hora_inicio','09:00') ?> – <?= wtb_opt('wtb_hora_fin','19:00') ?></div>
                    <div class="wtb-card-label">Horario activo</div>
                </div>
            </div>
        </div>

        <!-- Shortcode y acciones rápidas -->
        <div class="wtb-row">
            <div class="wtb-panel" style="flex:1">
                <h3><?= wtb_icon("copy") ?> Shortcode para tu página</h3>
                <p>Copia y pega este código en cualquier página o entrada:</p>
                <div class="wtb-shortcode-box">
                    <code id="wtb-sc">[widetech_booking]</code>
                    <button class="wtb-copy-btn" onclick="wtbCopy('wtb-sc')">Copiar</button>
                </div>
                <p class="wtb-hint">También puedes añadir el bloque "Shortcode" en el editor de Gutenberg.</p>
            </div>
            <div class="wtb-panel" style="flex:1">
                <h3><?= wtb_icon("wizard") ?> Acciones rápidas</h3>
                <a href="<?= admin_url('admin.php?page=wtb-settings&tab=google') ?>" class="wtb-btn wtb-btn-outline"><?= wtb_icon("settings",'',15) ?> Google Calendar</a>
                <a href="<?= admin_url('admin.php?page=wtb-settings&tab=diseno') ?>" class="wtb-btn wtb-btn-outline"><?= wtb_icon("palette",'',15) ?> Diseño</a>
                <a href="<?= admin_url('admin.php?page=wtb-bookings') ?>"             class="wtb-btn wtb-btn-outline"><?= wtb_icon("bookings",'',15) ?> Reservas</a>
                <a href="<?= admin_url('admin.php?page=wtb-wizard') ?>"               class="wtb-btn wtb-btn-outline"><?= wtb_icon("wizard",'',15) ?> Asistente</a>
            </div>
        </div>

        <!-- Últimas reservas -->
        <?php if ( $recientes ): ?>
        <div class="wtb-panel">
            <h3><?= wtb_icon("bookings") ?> Últimas reservas</h3>
            <table class="wtb-table">
                <thead><tr><th>Nombre</th><th>Email</th><th>Fecha</th><th>Estado</th><th>Origen</th></tr></thead>
                <tbody>
                <?php foreach ($recientes as $r): ?>
                    <tr>
                        <td><?= esc_html($r['nombre']) ?></td>
                        <td><?= esc_html($r['email'])  ?></td>
                        <td><?= date_i18n('d/m/Y H:i', strtotime($r['fecha_inicio'])) ?></td>
                        <td><span class="wtb-badge wtb-badge-<?= $r['estado'] ?>"><?= $r['estado'] ?></span></td>
                        <td><?= $r['origen'] ?></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
            <a href="<?= admin_url('admin.php?page=wtb-bookings') ?>" class="wtb-link-more">Ver todas →</a>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   PAGE: WIZARD
══════════════════════════════════════════════════════════════ */
function wtb_page_wizard(): void {
    $step = (int) ($_GET['step'] ?? get_option('wtb_wizard_step', 1));
    ?>
    <div class="wrap wtb-wrap">
        <div class="wtb-header">
            <div class="wtb-header-logo"><?= wtb_icon("wizard",'',20) ?> Asistente de configuración</div>
        </div>

        <!-- Barra de progreso -->
        <div class="wtb-wizard-progress">
            <?php
            $steps = ['1'=>'Bienvenida','2'=>'Google Cloud','3'=>'Credenciales','4'=>'Horarios','5'=>'¡Listo!'];
            foreach ($steps as $n => $label):
                $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
            ?>
            <div class="wtb-wiz-step <?= $cls ?>">
                <div class="wtb-wiz-num"><?= $n < $step ? '✓' : $n ?></div>
                <div class="wtb-wiz-label"><?= $label ?></div>
            </div>
            <?php if ($n < count($steps)): ?><div class="wtb-wiz-line <?= $n < $step ? 'done' : '' ?>"></div><?php endif ?>
            <?php endforeach ?>
        </div>

        <!-- Contenido del paso -->
        <div class="wtb-wizard-content">
        <?php
        if ( $step === 1 ):
        ?>
            <div class="wtb-wiz-card">
                <div class="wtb-wiz-icon"></div>
                <h2>¡Bienvenido a WIdeTech Booking!</h2>
                <p>Este asistente te guiará para configurar tu sistema de reservas en <strong>5 pasos sencillos</strong>, sin necesidad de escribir ni una línea de código.</p>
                <div class="wtb-wiz-checklist">
                    <div class="wtb-wiz-check">Calendario interactivo en tu web</div>
                    <div class="wtb-wiz-check">Reservas sincronizadas con tu Google Calendar</div>
                    <div class="wtb-wiz-check">Email de confirmación automático al cliente</div>
                    <div class="wtb-wiz-check">Diseño 100% personalizable desde el panel</div>
                    <div class="wtb-wiz-check">Sin código, sin plugins extra</div>
                </div>
                <a href="?page=wtb-wizard&step=2" class="wtb-btn wtb-btn-primary wtb-btn-lg">Empezar →</a>
            </div>

        <?php elseif ( $step === 2 ): ?>
            <div class="wtb-wiz-card">
                <div class="wtb-wiz-icon"></div>
                <h2>Paso 2 — Crear proyecto en Google Cloud</h2>
                <p>Necesitas crear un proyecto en Google Cloud para obtener las credenciales. Solo lo harás una vez.</p>

                <div class="wtb-wiz-steps-list">
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">1</span>
                        <div>Ve a <a href="https://console.cloud.google.com" target="_blank" class="wtb-link">console.cloud.google.com</a> e inicia sesión con el Gmail donde quieres recibir las reservas.</div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">2</span>
                        <div>Haz clic en el selector de proyectos (arriba a la izquierda) → <strong>"Proyecto nuevo"</strong> → nombre: <code>mis-reservas</code> → Crear.</div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">3</span>
                        <div>Ve a <strong>APIs y servicios → Biblioteca</strong> → busca <code>Google Calendar API</code> → haz clic → <strong>Habilitar</strong>.</div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">4</span>
                        <div>Ve a <strong>APIs y servicios → Pantalla de consentimiento OAuth</strong> → Externo → Crear → rellena nombre y email → Guardar y continuar (en todos los pasos).</div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">5</span>
                        <div>Ve a <strong>APIs y servicios → Credenciales → + Crear credenciales → ID de cliente OAuth</strong> → Tipo: <strong>Aplicación web</strong> → nombre: <code>WordPress Reservas</code>.</div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">6</span>
                        <div>En <strong>"URIs de redireccionamiento autorizados"</strong> añade exactamente esta URL:
                            <div class="wtb-code-block">
                                <code><?= esc_html(WTB_GCal::get_redirect_uri()) ?></code>
                                <button class="wtb-copy-btn-sm" onclick="navigator.clipboard.writeText('<?= esc_js(WTB_GCal::get_redirect_uri()) ?>')">Copiar</button>
                            </div>
                        </div>
                    </div>
                    <div class="wtb-wiz-item">
                        <span class="wtb-wiz-item-num">7</span>
                        <div>Haz clic en <strong>Crear</strong>. Google te mostrará el <strong>Client ID</strong> y <strong>Client Secret</strong>. Guárdalos, los necesitas en el siguiente paso.</div>
                    </div>
                </div>

                <div class="wtb-wiz-nav">
                    <a href="?page=wtb-wizard&step=1" class="wtb-btn wtb-btn-ghost">← Anterior</a>
                    <a href="?page=wtb-wizard&step=3" class="wtb-btn wtb-btn-primary">Ya tengo mis credenciales →</a>
                </div>
            </div>

        <?php elseif ( $step === 3 ): ?>
            <div class="wtb-wiz-card">
                <div class="wtb-wiz-icon"></div>
                <h2>Paso 3 — Conectar con Google Calendar</h2>
                <p>Pega aquí las credenciales que obtuviste en Google Cloud.</p>

                <form method="post">
                    <?php wp_nonce_field('wtb_settings'); ?>
                    <input type="hidden" name="wtb_save_settings" value="1">
                    <input type="hidden" name="wtb_current_tab" value="google">

                    <div class="wtb-wiz-form-group">
                        <label>Client ID <span class="wtb-req">*</span></label>
                        <input type="text" name="wtb_gcal_client_id" class="wtb-wiz-input"
                               value="<?= esc_attr(wtb_opt('wtb_gcal_client_id')) ?>"
                               placeholder="xxxxxxxx.apps.googleusercontent.com" required>
                    </div>
                    <div class="wtb-wiz-form-group">
                        <label>Client Secret <span class="wtb-req">*</span></label>
                        <input type="password" name="wtb_gcal_client_secret" class="wtb-wiz-input"
                               value="<?= esc_attr(wtb_opt('wtb_gcal_client_secret')) ?>"
                               placeholder="GOCSPX-xxxxxxxxxxxxxxxxx" required>
                        <span class="wtb-hint">Se guarda cifrado en tu base de datos de WordPress.</span>
                    </div>
                    <div class="wtb-wiz-form-group">
                        <label>Calendar ID</label>
                        <input type="text" name="wtb_gcal_calendar_id" class="wtb-wiz-input"
                               value="<?= esc_attr(wtb_opt('wtb_gcal_calendar_id','primary')) ?>"
                               placeholder="primary">
                        <span class="wtb-hint">Usa <code>primary</code> para tu calendario principal. O busca el ID en Google Calendar → ⚙️ → Configuración → tu calendario → "ID del calendario".</span>
                    </div>

                    <?php
                    $gcal = new WTB_GCal();
                    $connected = $gcal->is_connected();
                    ?>

                    <div class="wtb-wiz-actions">
                        <?php if ( $connected ): ?>
                            <div class="wtb-alert wtb-alert-success">Google Calendar conectado correctamente.</div>
                        <?php endif; ?>

                        <button type="submit" class="wtb-btn wtb-btn-secondary"><?= wtb_icon("check",'',15) ?> Guardar credenciales</button>

                        <?php if ( wtb_opt('wtb_gcal_client_id') ): ?>
                            <a href="<?= esc_url($gcal->get_auth_url()) ?>" class="wtb-btn wtb-btn-google">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;margin-right:8px"><path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z" fill="#4285F4"/><path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z" fill="#34A853"/><path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z" fill="#FBBC05"/><path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z" fill="#EA4335"/></svg>
                                Conectar con Google Calendar
                            </a>
                        <?php else: ?>
                            <p class="wtb-hint">⚠️ Guarda las credenciales primero para poder conectar.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Botón de test -->
                    <?php if ( $connected ): ?>
                    <div style="margin-top:16px;">
                        <button type="button" id="wtb-test-btn" class="wtb-btn wtb-btn-outline">🔌 Probar conexión ahora</button>
                        <div id="wtb-test-result" style="margin-top:10px;"></div>
                    </div>
                    <?php endif; ?>

                </form>

                <div class="wtb-wiz-nav" style="margin-top:24px;">
                    <a href="?page=wtb-wizard&step=2" class="wtb-btn wtb-btn-ghost">← Anterior</a>
                    <?php if ($connected): ?>
                    <a href="?page=wtb-wizard&step=4" class="wtb-btn wtb-btn-primary">Siguiente →</a>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ( $step === 4 ): ?>
            <div class="wtb-wiz-card">
                <div class="wtb-wiz-icon"></div>
                <h2>Paso 4 — Configura tus horarios</h2>
                <p>Define cuándo estás disponible para citas. Podrás cambiarlo en cualquier momento desde Ajustes.</p>

                <form method="post">
                    <?php wp_nonce_field('wtb_settings'); ?>
                    <input type="hidden" name="wtb_save_settings" value="1">
                    <input type="hidden" name="wtb_current_tab" value="horarios">
                    <input type="hidden" name="wtb_wizard_step" value="4">

                    <div class="wtb-wiz-form-row">
                        <div class="wtb-wiz-form-group">
                            <label>Duración de cada cita</label>
                            <select name="wtb_slot_duration" class="wtb-wiz-select">
                                <?php foreach ([15,20,30,45,60,90,120] as $m): ?>
                                <option value="<?=$m?>" <?= selected(wtb_opt('wtb_slot_duration','60'),$m,false) ?>><?=$m?> minutos</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="wtb-wiz-form-group">
                            <label>Reservas con hasta X días de antelación</label>
                            <input type="number" name="wtb_dias_max_futuro" class="wtb-wiz-input"
                                   value="<?= esc_attr(wtb_opt('wtb_dias_max_futuro','60')) ?>" min="1" max="365">
                        </div>
                    </div>

                    <div class="wtb-wiz-form-row">
                        <div class="wtb-wiz-form-group">
                            <label>Hora de inicio</label>
                            <input type="time" name="wtb_hora_inicio" class="wtb-wiz-input"
                                   value="<?= esc_attr(wtb_opt('wtb_hora_inicio','09:00')) ?>">
                        </div>
                        <div class="wtb-wiz-form-group">
                            <label>Hora de fin</label>
                            <input type="time" name="wtb_hora_fin" class="wtb-wiz-input"
                                   value="<?= esc_attr(wtb_opt('wtb_hora_fin','19:00')) ?>">
                        </div>
                    </div>

                    <div class="wtb-wiz-form-group">
                        <label>Días laborables</label>
                        <div class="wtb-days-grid">
                            <?php
                            $dias_activos = (json_decode(wtb_opt('wtb_dias','[1,2,3,4,5]'), true) ?: [1,2,3,4,5]);
                            $dias = [1=>'Lun',2=>'Mar',3=>'Mié',4=>'Jue',5=>'Vie',6=>'Sáb',0=>'Dom'];
                            foreach ($dias as $n => $l):
                                $checked = in_array($n,(array)$dias_activos) ? 'checked' : '';
                            ?>
                            <label class="wtb-day-pill <?= $checked ? 'active' : '' ?>">
                                <input type="checkbox" name="wtb_dias[]" value="<?=$n?>" <?=$checked?>> <?=$l?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="wtb-wiz-nav">
                        <a href="?page=wtb-wizard&step=3" class="wtb-btn wtb-btn-ghost">← Anterior</a>
                        <button type="submit" class="wtb-btn wtb-btn-primary">Guardar y continuar →</button>
                    </div>
                </form>
            </div>

        <?php elseif ( $step >= 5 ): update_option('wtb_show_wizard','0'); ?>
            <div class="wtb-wiz-card wtb-wiz-done">
                <div class="wtb-wiz-icon"></div>
                <h2>¡Todo listo!</h2>
                <p>Tu sistema de reservas está configurado. Añade el shortcode en cualquier página:</p>
                <div class="wtb-shortcode-box wtb-shortcode-big">
                    <code>[widetech_booking]</code>
                    <button class="wtb-copy-btn" onclick="navigator.clipboard.writeText('[widetech_booking]')">Copiar</button>
                </div>
                <div class="wtb-wiz-actions" style="justify-content:center;margin-top:24px;gap:12px;">
                    <a href="<?= admin_url('admin.php?page=wtb-dashboard') ?>" class="wtb-btn wtb-btn-primary">📊 Ir al Dashboard</a>
                    <a href="<?= admin_url('admin.php?page=wtb-settings')  ?>" class="wtb-btn wtb-btn-outline">⚙️ Personalizar más</a>
                </div>
            </div>
        <?php endif; ?>
        </div>
    </div>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   PAGE: SETTINGS (con pestañas)
══════════════════════════════════════════════════════════════ */
function wtb_page_settings(): void {
    $tab  = $_GET['tab'] ?? 'google';
    $tabs = ['google'=>'<?= wtb_icon("google","",16) ?> Google','horarios'=>'<?= wtb_icon("clock","",16) ?> Horarios','diseno'=>'<?= wtb_icon("palette","",16) ?> Diseño','formulario'=>'<?= wtb_icon("form","",16) ?> Formulario','emails'=>'<?= wtb_icon("email","",16) ?> Emails','whatsapp'=>'<?= wtb_icon("whatsapp","",16) ?> WhatsApp'];
    ?>
    <div class="wrap wtb-wrap">
        <div class="wtb-header">
            <div class="wtb-header-logo"><?= wtb_icon("settings") ?> Ajustes</div>
        </div>

        <?php if ( isset($_GET['saved']) ): ?>
        <div class="wtb-alert wtb-alert-success" style="margin-bottom:16px;">Ajustes guardados correctamente.</div>
        <?php endif; ?>

        <div class="wtb-tabs-nav">
            <?php foreach ($tabs as $k => $label): ?>
            <a href="?page=wtb-settings&tab=<?=$k?>" class="wtb-tab <?= $tab===$k ? 'active':'' ?>"><?=$label?></a>
            <?php endforeach; ?>
        </div>

        <form method="post" class="wtb-settings-form">
            <?php wp_nonce_field('wtb_settings'); ?>
            <input type="hidden" name="wtb_save_settings" value="1">
            <input type="hidden" name="wtb_current_tab" value="<?= esc_attr($tab) ?>">

            <?php if ($tab === 'google'): ?>
            <!-- ─── PESTAÑA: GOOGLE ─────────────────────────────── -->
            <div class="wtb-panel">
                <h3><?= wtb_icon("google") ?> Credenciales de Google Calendar</h3>
                <p>URI de redirección OAuth — cópiala en Google Cloud Console:</p>
                <div class="wtb-code-block">
                    <code><?= esc_html(WTB_GCal::get_redirect_uri()) ?></code>
                    <button type="button" class="wtb-copy-btn-sm" onclick="navigator.clipboard.writeText('<?= esc_js(WTB_GCal::get_redirect_uri()) ?>')">Copiar</button>
                </div>
                <?php
                $wp_tz_str  = get_option('timezone_string');
                $gmt_offset = get_option('gmt_offset', 0);
                $tz_display = $wp_tz_str ?: 'UTC';
                $tz_ok      = ! empty($wp_tz_str);
                ?>
                <div class="wtb-alert <?= $tz_ok ? 'wtb-alert-info' : 'wtb-alert-error' ?>" style="margin:12px 0 16px;">
                    <?php if ( ! $tz_ok ): ?>
                        ⚠️ <strong>¡Zona horaria de WordPress no configurada!</strong>
                        Tu sitio usa <strong>UTC</strong>, lo que causa que las reservas aparezcan
                        con hora incorrecta en Google Calendar.
                        <a href="<?= esc_url(admin_url('options-general.php')) ?>" target="_blank"
                           style="font-weight:700;margin-left:4px;">
                            → Ir a Ajustes Generales → Zona horaria
                        </a>
                        <br><small>Ejemplo: <strong>America/Caracas</strong> (Venezuela),
                        <strong>America/Bogota</strong> (Colombia), <strong>America/Mexico_City</strong></small>
                    <?php else: ?>
                        Zona horaria: <strong><?= esc_html($tz_display) ?></strong>.
                        Debe coincidir con la zona de tu Google Calendar para que las horas sean correctas.
                    <?php endif; ?>
                </div>
                <table class="wtb-form-table">
                    <tr><th><label>Client ID</label></th>
                        <td><input type="text" name="wtb_gcal_client_id" class="wtb-input wtb-input-lg"
                                   value="<?= esc_attr(wtb_opt('wtb_gcal_client_id')) ?>"
                                   placeholder="xxxxxxxx.apps.googleusercontent.com"></td></tr>
                    <tr><th><label>Client Secret</label></th>
                        <td><input type="password" name="wtb_gcal_client_secret" class="wtb-input wtb-input-lg"
                                   value="<?= esc_attr(wtb_opt('wtb_gcal_client_secret')) ?>"></td></tr>
                    <tr><th><label>Calendar ID</label></th>
                        <td><input type="text" name="wtb_gcal_calendar_id" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_gcal_calendar_id','primary')) ?>"
                                   placeholder="primary">
                            <p class="wtb-hint">Usa <code>primary</code> o el ID específico de tu calendario.</p></td></tr>
                </table>
                <?php $gcal = new WTB_GCal(); $connected = $gcal->is_connected(); ?>
                <div class="wtb-gcal-status <?= $connected ? 'connected' : 'disconnected' ?>">
                    <?php if ($connected): ?>
                        <span>Google Calendar conectado</span>
                        <a href="<?= wp_nonce_url(admin_url('admin.php?page=wtb-settings&tab=google&wtb_disconnect=1'),'wtb_disconnect') ?>" class="wtb-link-danger">Desconectar</a>
                    <?php else: ?>
                        <span>⚠️ No conectado</span>
                    <?php endif; ?>
                </div>
                <div class="wtb-form-actions">
                    <button type="submit" class="wtb-btn wtb-btn-primary"><?= wtb_icon("check",'',15) ?> Guardar credenciales</button>
                    <?php if ( wtb_opt('wtb_gcal_client_id') && ! $connected ): ?>
                    <a href="<?= esc_url($gcal->get_auth_url()) ?>" class="wtb-btn wtb-btn-google">
                        <svg width="16" height="16" viewBox="0 0 18 18" fill="none" style="vertical-align:middle;margin-right:6px"><path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 0 1-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615Z" fill="#4285F4"/><path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18Z" fill="#34A853"/><path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332Z" fill="#FBBC05"/><path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58Z" fill="#EA4335"/></svg>
                        Conectar con Google
                    </a>
                    <?php endif; ?>
                    <?php if ($connected): ?>
                    <button type="button" id="wtb-test-btn" class="wtb-btn wtb-btn-outline">🔌 Probar conexión</button>
                    <div id="wtb-test-result"></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php elseif ($tab === 'horarios'): ?>
            <!-- ─── PESTAÑA: HORARIOS ──────────────────────────── -->
            <div class="wtb-panel">
                <h3><?= wtb_icon("clock") ?> Disponibilidad y horarios</h3>
                <table class="wtb-form-table">
                    <tr><th><label>Duración de cada cita</label></th>
                        <td><select name="wtb_slot_duration" class="wtb-select">
                            <?php foreach ([15,20,30,45,60,90,120] as $m): ?>
                            <option value="<?=$m?>" <?= selected(wtb_opt('wtb_slot_duration','60'),$m,false) ?>><?=$m?> min</option>
                            <?php endforeach; ?>
                        </select></td></tr>
                    <tr><th><label>Hora de inicio</label></th>
                        <td><input type="time" name="wtb_hora_inicio" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_hora_inicio','09:00')) ?>"></td></tr>
                    <tr><th><label>Hora de fin</label></th>
                        <td><input type="time" name="wtb_hora_fin" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_hora_fin','19:00')) ?>"></td></tr>
                    <tr><th><label>Días laborables</label></th>
                        <td>
                        <?php
                        $da  = (json_decode(wtb_opt('wtb_dias','[1,2,3,4,5]'), true) ?: [1,2,3,4,5]);
                        $dns = [1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes',6=>'Sábado',0=>'Domingo'];
                        foreach($dns as $n=>$l):
                            $ch = in_array($n,(array)$da)?'checked':'';
                        ?>
                        <label class="wtb-day-pill <?= $ch?'active':'' ?>">
                            <input type="checkbox" name="wtb_dias[]" value="<?=$n?>" <?=$ch?>> <?=$l?>
                        </label>
                        <?php endforeach; ?>
                        </td></tr>
                    <tr><th><label>Reservar hasta X días en el futuro</label></th>
                        <td><input type="number" name="wtb_dias_max_futuro" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_dias_max_futuro','60')) ?>" min="1" max="365">
                            <span class="wtb-hint">Los usuarios no podrán reservar más allá de este límite.</span></td></tr>
                    <tr><th><label>Vista inicial del calendario</label></th>
                        <td><select name="wtb_vista_inicial" class="wtb-select">
                            <option value="timeGridWeek"  <?= selected(wtb_opt('wtb_vista_inicial'),'timeGridWeek',false)  ?>>Vista semanal</option>
                            <option value="timeGridDay"   <?= selected(wtb_opt('wtb_vista_inicial'),'timeGridDay',false)   ?>>Vista diaria</option>
                            <option value="dayGridMonth"  <?= selected(wtb_opt('wtb_vista_inicial'),'dayGridMonth',false)  ?>>Vista mensual</option>
                        </select></td></tr>
                </table>
            </div>

            <?php elseif ($tab === 'diseno'): ?>
            <!-- ─── PESTAÑA: DISEÑO ───────────────────────────── -->

            <!-- SELECTOR DE TEMA -->
            <div class="wtb-panel" style="margin-bottom:20px;">
                <h3>🎨 Tema del calendario</h3>
                <div class="wtb-theme-selector">
                    <?php $current_theme = wtb_opt('wtb_theme','light'); ?>
                    <label class="wtb-theme-card <?= $current_theme==='light'?'active':'' ?>">
                        <input type="radio" name="wtb_theme" value="light" <?= checked($current_theme,'light',false) ?>>
                        <div class="wtb-theme-preview wtb-theme-light">
                            <div class="wtb-tp-header"></div>
                            <div class="wtb-tp-body">
                                <div class="wtb-tp-row"></div><div class="wtb-tp-row"></div><div class="wtb-tp-row wtb-tp-occ"></div>
                            </div>
                        </div>
                        <span>☀️ Light</span>
                    </label>
                    <label class="wtb-theme-card <?= $current_theme==='dark'?'active':'' ?>">
                        <input type="radio" name="wtb_theme" value="dark" <?= checked($current_theme,'dark',false) ?>>
                        <div class="wtb-theme-preview wtb-theme-dark">
                            <div class="wtb-tp-header"></div>
                            <div class="wtb-tp-body">
                                <div class="wtb-tp-row"></div><div class="wtb-tp-row"></div><div class="wtb-tp-row wtb-tp-occ"></div>
                            </div>
                        </div>
                        <span>🌙 Dark</span>
                    </label>
                    <label class="wtb-theme-card <?= $current_theme==='custom'?'active':'' ?>">
                        <input type="radio" name="wtb_theme" value="custom" <?= checked($current_theme,'custom',false) ?>>
                        <div class="wtb-theme-preview wtb-theme-custom">
                            <div class="wtb-tp-header"></div>
                            <div class="wtb-tp-body">
                                <div class="wtb-tp-row"></div><div class="wtb-tp-row"></div><div class="wtb-tp-row wtb-tp-occ"></div>
                            </div>
                        </div>
                        <span>🎨 Personalizado</span>
                    </label>
                </div>
                <p class="wtb-hint">El tema <strong>Personalizado</strong> toma los colores y tipografía que configures abajo.</p>
            </div>

            <!-- POSICIÓN DEL BOTÓN -->
            <div class="wtb-panel" style="margin-bottom:20px;">
                <h3>📍 Posición del botón "Reservar"</h3>
                <div style="display:flex;gap:16px;flex-wrap:wrap;">
                    <?php $bp = wtb_opt('wtb_btn_position','bottom'); ?>
                    <label class="wtb-pos-card <?= $bp==='top'?'active':'' ?>">
                        <input type="radio" name="wtb_btn_position" value="top" <?= checked($bp,'top',false) ?>>
                        <div class="wtb-pos-preview">
                            <div class="wtb-pos-btn-top"></div>
                            <div class="wtb-pos-cal"></div>
                        </div>
                        <span>⬆️ Arriba del calendario</span>
                    </label>
                    <label class="wtb-pos-card <?= $bp==='bottom'?'active':'' ?>">
                        <input type="radio" name="wtb_btn_position" value="bottom" <?= checked($bp,'bottom',false) ?>>
                        <div class="wtb-pos-preview">
                            <div class="wtb-pos-cal"></div>
                            <div class="wtb-pos-btn-bot"></div>
                        </div>
                        <span>⬇️ Abajo del calendario</span>
                    </label>
                </div>
            </div>

            <!-- ICONOS CONFIGURABLES -->
            <div class="wtb-panel" style="margin-bottom:20px;">
                <h3><?= wtb_icon('calendar') ?> Iconos del calendario</h3>
                <p class="wtb-hint" style="margin-bottom:16px;">Elige el símbolo para slots ocupados y las etiquetas del modal. Puedes usar emojis o dejar vacío para el icono SVG por defecto.</p>
                <table class="wtb-form-table">
                    <tr>
                        <th><label>Icono slot ocupado</label></th>
                        <td>
                            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
                                <?php
                                $lock_opts = [ '' => 'SVG (default)', '🔒' => '🔒', '🔐' => '🔐', '✕' => '✕', '—' => '—' ];
                                $cur_lock  = wtb_opt('wtb_lock_icon_char','');
                                foreach ($lock_opts as $v => $lbl):
                                ?>
                                <label class="wtb-icon-pill <?= $cur_lock===$v?'active':'' ?>">
                                    <input type="radio" name="wtb_lock_icon_char" value="<?= esc_attr($v) ?>" <?= checked($cur_lock,$v,false) ?>>
                                    <span><?= $lbl ?></span>
                                </label>
                                <?php endforeach; ?>
                            </div>
                            <input type="text" name="wtb_lock_icon_custom" class="wtb-input wtb-input-sm"
                                   value="<?= esc_attr(wtb_opt('wtb_lock_icon_custom','')) ?>"
                                   placeholder="Emoji personalizado…">
                        </td>
                    </tr>
                    <tr>
                        <th><label>Etiqueta Fecha (modal)</label></th>
                        <td><input type="text" name="wtb_icon_label_fecha" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_icon_label_fecha','Fecha')) ?>"
                                   placeholder="Fecha"></td>
                    </tr>
                    <tr>
                        <th><label>Etiqueta Hora (modal)</label></th>
                        <td><input type="text" name="wtb_icon_label_hora" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_icon_label_hora','Hora disponible')) ?>"
                                   placeholder="Hora disponible"></td>
                    </tr>
                </table>
            </div>

            <!-- Resto de opciones (solo relevantes para tema Custom) -->
            <div id="wtb-custom-options" style="<?= $current_theme!=='custom'?'opacity:.4;pointer-events:none;':''; ?>">
            <div class="wtb-row" style="align-items:flex-start;gap:24px;">

                <!-- Columna izquierda: controles -->
                <div style="flex:1.3;min-width:0;">

                    <!-- COLORES -->
                    <div class="wtb-panel">
                        <h3><?= wtb_icon("palette") ?> Colores</h3>
                        <table class="wtb-form-table">
                            <tr><th><label>Color principal (botones y selección)</label></th>
                                <td><input type="text" name="wtb_color_primario" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_color_primario','#4f46e5')) ?>"></td></tr>
                            <tr><th><label>Color hover del botón</label></th>
                                <td><input type="text" name="wtb_color_hover" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_color_hover','#4338ca')) ?>"></td></tr>
                            <tr><th><label>Color texto del botón</label></th>
                                <td><input type="text" name="wtb_color_texto_btn" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_color_texto_btn','#ffffff')) ?>"></td></tr>
                            <tr><th><label>Color slots ocupados</label></th>
                                <td><input type="text" name="wtb_color_ocupado" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_color_ocupado','#ef4444')) ?>"></td></tr>
                        </table>
                    </div>

                    <!-- TIPOGRAFÍA -->
                    <div class="wtb-panel" style="margin-top:16px;">
                        <h3><?= wtb_icon("form") ?> Tipografía</h3>
                        <table class="wtb-form-table">
                            <tr>
                                <th><label for="wtb_font_family">Fuente del calendario</label></th>
                                <td>
                                    <select name="wtb_font_family" id="wtb_font_family" class="wtb-select wtb-font-select">
                                        <?php
                                        $ff_current = wtb_opt('wtb_font_family','inherit');
                                        $fonts = [
                                            'inherit'                          => '— Heredar del tema —',
                                            'system-ui, sans-serif'            => 'Sistema (por defecto)',
                                            "'Inter', sans-serif"              => 'Inter',
                                            "'Roboto', sans-serif"             => 'Roboto',
                                            "'Open Sans', sans-serif"          => 'Open Sans',
                                            "'Lato', sans-serif"               => 'Lato',
                                            "'Poppins', sans-serif"            => 'Poppins',
                                            "'Nunito', sans-serif"             => 'Nunito',
                                            "'Montserrat', sans-serif"         => 'Montserrat',
                                            "'Raleway', sans-serif"            => 'Raleway',
                                            "'Playfair Display', serif"        => 'Playfair Display (serif)',
                                            "Georgia, serif"                   => 'Georgia (serif)',
                                            "'Courier New', monospace"         => 'Courier New (mono)',
                                        ];
                                        foreach ($fonts as $val => $label):
                                        ?>
                                        <option value="<?= esc_attr($val) ?>" <?= selected($ff_current,$val,false) ?>><?= esc_html($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="wtb-hint">Las fuentes de Google (Inter, Poppins…) se cargan automáticamente.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>Tamaño título del modal</th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_font_size_titulo" min="0.8" max="2.5" step="0.05"
                                               value="<?= esc_attr(wtb_opt('wtb_font_size_titulo','1.2')) ?>"
                                               class="wtb-range" id="wtb-range-fs-titulo">
                                        <span class="wtb-range-val" id="wtb-range-fs-titulo-val"><?= wtb_opt('wtb_font_size_titulo','1.2') ?>rem</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Peso título</th>
                                <td>
                                    <select name="wtb_font_weight_titulo" class="wtb-select wtb-select-sm">
                                        <?php foreach (['300'=>'Light (300)','400'=>'Regular (400)','500'=>'Medium (500)','600'=>'Semibold (600)','700'=>'Bold (700)','800'=>'Extrabold (800)'] as $w=>$l): ?>
                                        <option value="<?=$w?>" <?= selected(wtb_opt('wtb_font_weight_titulo','700'),$w,false) ?>><?=$l?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>Tamaño etiquetas del formulario</th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_font_size_label" min="0.7" max="1.2" step="0.025"
                                               value="<?= esc_attr(wtb_opt('wtb_font_size_label','0.875')) ?>"
                                               class="wtb-range" id="wtb-range-fs-label">
                                        <span class="wtb-range-val" id="wtb-range-fs-label-val"><?= wtb_opt('wtb_font_size_label','0.875') ?>rem</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Peso etiquetas</th>
                                <td>
                                    <select name="wtb_font_weight_label" class="wtb-select wtb-select-sm">
                                        <?php foreach (['400'=>'Regular (400)','500'=>'Medium (500)','600'=>'Semibold (600)','700'=>'Bold (700)'] as $w=>$l): ?>
                                        <option value="<?=$w?>" <?= selected(wtb_opt('wtb_font_weight_label','600'),$w,false) ?>><?=$l?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>Tamaño campos de texto</th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_font_size_input" min="0.7" max="1.3" step="0.025"
                                               value="<?= esc_attr(wtb_opt('wtb_font_size_input','0.95')) ?>"
                                               class="wtb-range" id="wtb-range-fs-input">
                                        <span class="wtb-range-val" id="wtb-range-fs-input-val"><?= wtb_opt('wtb_font_size_input','0.95') ?>rem</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Tamaño texto del botón</th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_font_size_btn" min="0.8" max="1.4" step="0.025"
                                               value="<?= esc_attr(wtb_opt('wtb_font_size_btn','1')) ?>"
                                               class="wtb-range" id="wtb-range-fs-btn">
                                        <span class="wtb-range-val" id="wtb-range-fs-btn-val"><?= wtb_opt('wtb_font_size_btn','1') ?>rem</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Peso texto del botón</th>
                                <td>
                                    <select name="wtb_font_weight_btn" class="wtb-select wtb-select-sm">
                                        <?php foreach (['400'=>'Regular (400)','500'=>'Medium (500)','600'=>'Semibold (600)','700'=>'Bold (700)','800'=>'Extrabold (800)'] as $w=>$l): ?>
                                        <option value="<?=$w?>" <?= selected(wtb_opt('wtb_font_weight_btn','700'),$w,false) ?>><?=$l?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- BORDES Y SOMBRAS -->
                    <div class="wtb-panel" style="margin-top:16px;">
                        <h3><?= wtb_icon("settings") ?> Bordes y sombras</h3>
                        <table class="wtb-form-table">
                            <tr><th><label>Radio del modal (px)</label></th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_radio_modal" min="0" max="32"
                                               value="<?= esc_attr(wtb_opt('wtb_radio_modal','12')) ?>"
                                               class="wtb-range" id="wtb-range-modal">
                                        <span class="wtb-range-val" id="wtb-range-modal-val"><?= wtb_opt('wtb_radio_modal','12') ?>px</span>
                                    </div>
                                </td></tr>
                            <tr><th><label>Radio del botón (px)</label></th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_radio_btn" min="0" max="32"
                                               value="<?= esc_attr(wtb_opt('wtb_radio_btn','8')) ?>"
                                               class="wtb-range" id="wtb-range-btn">
                                        <span class="wtb-range-val" id="wtb-range-btn-val"><?= wtb_opt('wtb_radio_btn','8') ?>px</span>
                                    </div>
                                </td></tr>
                            <tr><th><label>Sombra en el modal</label></th>
                                <td><label class="wtb-toggle">
                                    <input type="checkbox" name="wtb_sombra_modal" <?= checked(wtb_opt('wtb_sombra_modal','1'),'1',false) ?>>
                                    <span class="wtb-toggle-slider"></span>
                                    <span class="wtb-toggle-label">Activar sombra</span>
                                </label></td></tr>
                        </table>
                    </div>

                    <!-- COLORES DEL CALENDARIO -->
                    <div class="wtb-panel" style="margin-top:16px;">
                        <h3><?= wtb_icon("calendar") ?> Colores del calendario</h3>
                        <table class="wtb-form-table">
                            <tr><th><label>Fondo del calendario</label></th>
                                <td><input type="text" name="wtb_cal_bg" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_bg','#ffffff')) ?>"></td></tr>
                            <tr><th><label>Fondo de cabeceras (días/horas)</label></th>
                                <td><input type="text" name="wtb_cal_header_bg" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_header_bg','#f8f9fc')) ?>"></td></tr>
                            <tr><th><label>Texto de cabeceras</label></th>
                                <td><input type="text" name="wtb_cal_header_text" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_header_text','#1e293b')) ?>"></td></tr>
                            <tr><th><label>Color de bordes/líneas</label></th>
                                <td><input type="text" name="wtb_cal_border" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_border','#e2e8f0')) ?>"></td></tr>
                            <tr><th><label>Fondo del día de hoy</label></th>
                                <td><input type="text" name="wtb_cal_today_bg" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_today_bg','#fff8e1')) ?>"></td></tr>
                            <tr><th><label>Borde del día de hoy</label></th>
                                <td><input type="text" name="wtb_cal_today_border" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_today_border','#f59e0b')) ?>"></td></tr>
                            <tr><th><label>Línea de hora actual</label></th>
                                <td><input type="text" name="wtb_cal_now_line" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_now_line','#ef4444')) ?>"></td></tr>
                            <tr><th><label>Color al pasar por slot libre</label></th>
                                <td><input type="text" name="wtb_cal_slot_hover" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_slot_hover','#f1f0ff')) ?>"></td></tr>
                            <tr><th><label>Color de texto general</label></th>
                                <td><input type="text" name="wtb_cal_text" class="wtb-color-picker"
                                           value="<?= esc_attr(wtb_opt('wtb_cal_text','#334155')) ?>"></td></tr>
                            <tr><th><label>Radio del calendario (px)</label></th>
                                <td>
                                    <div class="wtb-range-wrap">
                                        <input type="range" name="wtb_cal_radius" min="0" max="24"
                                               value="<?= esc_attr(wtb_opt('wtb_cal_radius','12')) ?>"
                                               class="wtb-range" id="wtb-range-cal-radius">
                                        <span class="wtb-range-val" id="wtb-range-cal-radius-val"><?= wtb_opt('wtb_cal_radius','12') ?>px</span>
                                    </div>
                                </td></tr>
                        </table>
                    </div>

                    <!-- TEXTOS CALENDARIO -->
                    <div class="wtb-panel" style="margin-top:16px;">
                        <h3><?= wtb_icon("calendar") ?> Textos</h3>
                        <table class="wtb-form-table">
                            <tr><th><label>Texto en slots ocupados</label></th>
                                <td><input type="text" name="wtb_texto_ocupado" class="wtb-input"
                                           value="<?= esc_attr(wtb_opt('wtb_texto_ocupado','No disponible')) ?>"></td></tr>
                            <tr>
                                <th><label>Mensaje de instrucción</label></th>
                                <td>
                                    <input type="text" name="wtb_hint_text" class="wtb-input wtb-input-lg"
                                           value="<?= esc_attr(wtb_opt('wtb_hint_text','👆 Haz clic en el calendario o en el botón para reservar tu cita.')) ?>">
                                    <span class="wtb-hint">Se muestra encima del calendario. Déjalo vacío para ocultarlo.</span>
                                </td>
                            </tr>
                            <tr>
                                <th><label>Texto del botón "Reservar"</label></th>
                                <td>
                                    <input type="text" name="wtb_open_btn_label" class="wtb-input"
                                           value="<?= esc_attr(wtb_opt('wtb_open_btn_label','📅 Reservar cita')) ?>">
                                    <span class="wtb-hint">Botón principal que aparece debajo del calendario.</span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Columna derecha: vistas previas -->
                <div style="flex:1;position:sticky;top:32px;min-width:320px;">

                    <!-- PREVIEW: MODAL/FORMULARIO -->
                    <div class="wtb-panel">
                        <h3>👁️ Vista previa — Formulario de reserva</h3>
                        <div id="wtb-preview">
                            <div id="wtb-preview-modal">
                                <button id="wtb-preview-close" type="button">&times;</button>
                                <h4 id="wtb-preview-title"><?= esc_html(wtb_opt('wtb_titulo_modal','Solicitar cita')) ?></h4>
                                <p style="font-size:.78em;color:#64748b;margin:0 0 10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:6px 10px;">Lunes, 15 enero · 10:00 – 11:00</p>
                                <div class="wtb-preview-label" id="wtb-prev-lbl-nombre"><?= esc_html(wtb_opt('wtb_label_nombre','Nombre completo')) ?></div>
                                <div class="wtb-preview-input"><?= esc_html(wtb_opt('wtb_ph_nombre','Tu nombre completo')) ?></div>
                                <div class="wtb-preview-label" id="wtb-prev-lbl-email"><?= esc_html(wtb_opt('wtb_label_email','Correo electrónico')) ?></div>
                                <div class="wtb-preview-input"><?= esc_html(wtb_opt('wtb_ph_email','tu@email.com')) ?></div>
                                <button id="wtb-preview-btn" type="button"><?= esc_html(wtb_opt('wtb_btn_texto','Confirmar reserva')) ?></button>
                            </div>
                        </div>
                        <p class="wtb-hint" style="margin-top:8px;">Se actualiza en tiempo real al cambiar los ajustes.</p>
                    </div>

                    <!-- PREVIEW: CALENDARIO -->
                    <div class="wtb-panel" style="margin-top:16px;">
                        <h3>🗓️ Vista previa — Calendario</h3>
                        <div id="wtb-preview-cal">
                            <!-- Header del calendario -->
                            <div class="wtb-cal-header">
                                <div class="wtb-cal-nav">
                                    <span class="wtb-cal-nav-btn">‹</span>
                                    <strong class="wtb-cal-title">Enero 2025</strong>
                                    <span class="wtb-cal-nav-btn">›</span>
                                </div>
                                <div class="wtb-cal-views">
                                    <span class="wtb-cal-view-btn">Mes</span>
                                    <span class="wtb-cal-view-btn active" id="wtb-cal-view-active">Semana</span>
                                    <span class="wtb-cal-view-btn">Día</span>
                                </div>
                            </div>
                            <!-- Grid de días -->
                            <div class="wtb-cal-grid">
                                <div class="wtb-cal-time-col">
                                    <div class="wtb-cal-time-label"></div>
                                    <?php foreach (['9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'] as $h): ?>
                                    <div class="wtb-cal-time-label"><?=$h?></div>
                                    <?php endforeach; ?>
                                </div>
                                <?php
                                $days = ['Lun 13','Mar 14','Mié 15','Jue 16','Vie 17'];
                                // Which slots are "occupied" per day column (row index 0=9h, 1=10h...)
                                $occupied = [0=>[1], 1=>[3], 2=>[0,1], 3=>[5], 4=>[2]];
                                foreach ($days as $di => $day):
                                ?>
                                <div class="wtb-cal-day-col">
                                    <div class="wtb-cal-day-header <?= $di===2?'today':'' ?>"><?=$day?></div>
                                    <?php for ($row=0; $row<9; $row++): ?>
                                    <div class="wtb-cal-slot <?= in_array($row, $occupied[$di]??[]) ? 'wtb-cal-slot-occ' : 'wtb-cal-slot-free' ?>">
                                        <?php if (in_array($row, $occupied[$di]??[])): ?>
                                        <span class="wtb-cal-occ-label">🔒 <span class="wtb-occ-text"><?= esc_html(wtb_opt('wtb_texto_ocupado','No disponible')) ?></span></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php endfor; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <p class="wtb-hint" style="margin-top:8px;">Vista ilustrativa de cómo se verá en tu web.</p>
                    </div>
                </div>
            </div>
            </div><!-- /wtb-custom-options -->


            <?php elseif ($tab === 'formulario'): ?>
            <!-- ─── PESTAÑA: FORMULARIO ───────────────────────── -->
            <div class="wtb-panel">
                <h3><?= wtb_icon("form") ?> Título y botón</h3>
                <table class="wtb-form-table">
                    <tr><th><label>Título del modal</label></th>
                        <td><input type="text" name="wtb_titulo_modal" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_titulo_modal','Solicitar cita')) ?>"></td></tr>
                    <tr><th><label>Texto del botón de envío</label></th>
                        <td><input type="text" name="wtb_btn_texto" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_btn_texto','Confirmar reserva')) ?>"></td></tr>
                    <tr><th><label>Mensaje de éxito al reservar</label></th>
                        <td><input type="text" name="wtb_msg_exito" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_msg_exito','¡Reserva confirmada! Recibirás un email en breve.')) ?>"></td></tr>
                </table>
            </div>
            <div class="wtb-panel" style="margin-top:16px;">
                <h3><?= wtb_icon("form") ?> Campos del formulario</h3>
                <table class="wtb-form-table">
                    <tr>
                        <th>Nombre completo</th>
                        <td>
                            <input type="text" name="wtb_label_nombre" class="wtb-input wtb-input-sm" placeholder="Etiqueta"
                                   value="<?= esc_attr(wtb_opt('wtb_label_nombre','Nombre completo')) ?>">
                            <input type="text" name="wtb_ph_nombre" class="wtb-input wtb-input-sm" placeholder="Placeholder"
                                   value="<?= esc_attr(wtb_opt('wtb_ph_nombre','Tu nombre completo')) ?>">
                            <span class="wtb-badge wtb-badge-confirmada">Obligatorio</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td>
                            <input type="text" name="wtb_label_email" class="wtb-input wtb-input-sm" placeholder="Etiqueta"
                                   value="<?= esc_attr(wtb_opt('wtb_label_email','Correo electrónico')) ?>">
                            <input type="text" name="wtb_ph_email" class="wtb-input wtb-input-sm" placeholder="Placeholder"
                                   value="<?= esc_attr(wtb_opt('wtb_ph_email','tu@email.com')) ?>">
                            <span class="wtb-badge wtb-badge-confirmada">Obligatorio</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Teléfono</th>
                        <td>
                            <input type="text" name="wtb_label_tel" class="wtb-input wtb-input-sm" placeholder="Etiqueta"
                                   value="<?= esc_attr(wtb_opt('wtb_label_tel','Teléfono')) ?>">
                            <input type="text" name="wtb_ph_tel" class="wtb-input wtb-input-sm" placeholder="Placeholder"
                                   value="<?= esc_attr(wtb_opt('wtb_ph_tel','+34 600 000 000')) ?>">
                            <label class="wtb-check-label">
                                <input type="checkbox" name="wtb_campo_tel" <?= checked(wtb_opt('wtb_campo_tel','1'),'1',false) ?>> Mostrar
                            </label>
                            <label class="wtb-check-label">
                                <input type="checkbox" name="wtb_tel_required" <?= checked(wtb_opt('wtb_tel_required','0'),'1',false) ?>> Obligatorio
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>Notas</th>
                        <td>
                            <input type="text" name="wtb_label_notas" class="wtb-input wtb-input-sm" placeholder="Etiqueta"
                                   value="<?= esc_attr(wtb_opt('wtb_label_notas','Notas')) ?>">
                            <input type="text" name="wtb_ph_notas" class="wtb-input wtb-input-sm" placeholder="Placeholder"
                                   value="<?= esc_attr(wtb_opt('wtb_ph_notas','¿Algo que debamos saber?')) ?>">
                            <label class="wtb-check-label">
                                <input type="checkbox" name="wtb_campo_notas" <?= checked(wtb_opt('wtb_campo_notas','1'),'1',false) ?>> Mostrar
                            </label>
                        </td>
                    </tr>
                </table>
            </div>

            <?php elseif ($tab === 'emails'): ?>
            <!-- ─── PESTAÑA: EMAILS ───────────────────────────── -->
            <div class="wtb-panel">
                <h3><?= wtb_icon("email") ?> Email de confirmación</h3>
                <p>Variables disponibles: <code>{nombre}</code> <code>{fecha}</code> <code>{site}</code></p>
                <table class="wtb-form-table">
                    <tr><th><label>Asunto</label></th>
                        <td><input type="text" name="wtb_email_asunto" class="wtb-input wtb-input-lg"
                                   value="<?= esc_attr(wtb_opt('wtb_email_asunto','[{site}] Confirmación de reserva')) ?>"></td></tr>
                    <tr><th><label>Cuerpo del email</label></th>
                        <td><textarea name="wtb_email_cuerpo" class="wtb-textarea" rows="8"><?= esc_textarea(wtb_opt('wtb_email_cuerpo',"Hola {nombre},\n\nTu cita ha sido confirmada.\n\n📅 Fecha: {fecha}\n\nGracias,\n{site}")) ?></textarea></td></tr>
                </table>
            </div>
            <?php elseif ($tab === 'whatsapp'): ?>
            <!-- ─── PESTAÑA: WHATSAPP ──────────────────────── -->
            <div class="wtb-panel">
                <h3><?= wtb_icon("whatsapp") ?> WhatsApp</h3>
                <p>Usa <a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" target="_blank">CallMeBot</a> (gratis). Pasos: envía <strong>I allow callmebot to send me messages</strong> al número <strong>+34 644 80 77 22</strong> por WhatsApp. Recibirás tu API Key.</p>
                <table class="wtb-form-table">
                    <tr><th><label>Número WhatsApp del propietario</label></th>
                        <td><input type="text" name="wtb_wa_owner_number" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_wa_owner_number')) ?>"
                                   placeholder="+34600000000 (con código de país, sin espacios)"></td></tr>
                    <tr><th><label>API Key de CallMeBot</label></th>
                        <td><input type="text" name="wtb_wa_callmebot_key" class="wtb-input"
                                   value="<?= esc_attr(wtb_opt('wtb_wa_callmebot_key')) ?>"
                                   placeholder="123456"></td></tr>
                    <tr><th><label>Mensaje al propietario</label></th>
                        <td>
                            <textarea name="wtb_wa_msg_owner" class="wtb-textarea" rows="3"><?= esc_textarea(wtb_opt('wtb_wa_msg_owner','Nueva reserva: {nombre} | {fecha} | {email} | Tel: {telefono}')) ?></textarea>
                            <span class="wtb-hint">Variables: <code>{nombre} {fecha} {email} {telefono} {site}</code></span>
                        </td></tr>
                    <tr><th><label>Mensaje al cliente</label></th>
                        <td>
                            <textarea name="wtb_wa_msg_client" class="wtb-textarea" rows="3"><?= esc_textarea(wtb_opt('wtb_wa_msg_client','Hola {nombre}, tu cita ha sido confirmada para el {fecha}. Gracias!')) ?></textarea>
                            <span class="wtb-hint">Se envía al número WhatsApp que ingrese el cliente. Variables: <code>{nombre} {fecha} {site}</code></span>
                        </td></tr>
                </table>
                <div class="wtb-alert wtb-alert-info" style="margin-top:16px;">
                    ℹ️ Si el campo API Key está vacío, no se enviarán WhatsApps (el sistema seguirá funcionando con email).
                </div>
            </div>

            <?php endif; ?>

            <div class="wtb-form-save-bar">
                <button type="submit" class="wtb-btn wtb-btn-primary wtb-btn-lg"><?= wtb_icon("check",'',15) ?> Guardar cambios</button>
            </div>
        </form>
    </div>

    <?php
    // Manejar desconexión
    if ( isset($_GET['wtb_disconnect']) && check_admin_referer('wtb_disconnect') ) {
        WTB_GCal::disconnect();
        wp_safe_redirect(admin_url('admin.php?page=wtb-settings&tab=google&disconnected=1')); exit;
        exit;
    }
}

/* ══════════════════════════════════════════════════════════════
   PAGE: RESERVAS
══════════════════════════════════════════════════════════════ */
function wtb_page_bookings(): void {
    $per_page = 20;
    $paged    = max(1, (int)($_GET['paged'] ?? 1));
    $reservas = WTB_Database::get_all($per_page, ($paged-1)*$per_page);
    $total    = WTB_Database::count();
    $pages    = ceil($total / $per_page);
    ?>
    <div class="wrap wtb-wrap">
        <div class="wtb-header">
            <div class="wtb-header-logo"><?= wtb_icon("bookings") ?> Reservas</div>
            <div class="wtb-header-sub">Total: <strong><?=$total?></strong></div>
        </div>

        <?php if ( empty($reservas) ): ?>
        <div class="wtb-panel wtb-empty">
            <div style="font-size:3rem;">📭</div>
            <p>Aún no hay reservas. Cuando alguien reserve una cita desde tu web, aparecerá aquí.</p>
        </div>
        <?php else: ?>
        <div class="wtb-panel wtb-panel-flush">
            <table class="wtb-table wtb-table-full">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Fecha inicio</th>
                        <th>Fecha fin</th>
                        <th>Estado</th>
                        <th>Origen</th>
                        <th>Creada</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($reservas as $r): ?>
                    <tr>
                        <td><?= $r['id'] ?></td>
                        <td><?= esc_html($r['nombre']) ?></td>
                        <td><a href="mailto:<?= esc_attr($r['email']) ?>"><?= esc_html($r['email']) ?></a></td>
                        <td><?= esc_html($r['telefono'] ?: '—') ?></td>
                        <td><?= date_i18n('d/m/Y H:i', strtotime($r['fecha_inicio'])) ?></td>
                        <td><?= date_i18n('d/m/Y H:i', strtotime($r['fecha_fin']))    ?></td>
                        <td><span class="wtb-badge wtb-badge-<?= esc_attr($r['estado']) ?>"><?= $r['estado'] ?></span></td>
                        <td><?= $r['origen'] ?></td>
                        <td><?= date_i18n('d/m/Y H:i', strtotime($r['creado_en'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pages > 1): ?>
        <div class="wtb-pagination">
            <?php for ($i=1; $i<=$pages; $i++): ?>
            <a href="?page=wtb-bookings&paged=<?=$i?>" class="wtb-page-btn <?= $i===$paged?'active':'' ?>"><?=$i?></a>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}

/* ══════════════════════════════════════════════════════════════
   PAGE: OAUTH CALLBACK
══════════════════════════════════════════════════════════════ */
function wtb_page_oauth_callback(): void {
    if ( ! current_user_can('manage_options') ) wp_die('Sin permisos.');

    if ( isset($_GET['error']) ) {
        echo '<div class="wrap"><div class="notice notice-error"><p>❌ Google devolvió: '.esc_html($_GET['error']).'</p></div>
        <p><a href="'.admin_url('admin.php?page=wtb-settings&tab=google').'">← Volver</a></p></div>';
        return;
    }

    if ( isset($_GET['code']) ) {
        $gcal    = new WTB_GCal();
        $success = $gcal->handle_callback( sanitize_text_field($_GET['code']) );
        if ($success) {
            wp_safe_redirect(admin_url('admin.php?page=wtb-settings&tab=google&saved=1')); exit;
        } else {
            wp_safe_redirect(admin_url('admin.php?page=wtb-settings&tab=google&oauth_error=1')); exit;
        }
        exit;
    }
}
