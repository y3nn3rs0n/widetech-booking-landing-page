/* global FullCalendar, WTB */
document.addEventListener('DOMContentLoaded', function () {

    var wrap   = document.getElementById('wtb-wrap');
    var calEl  = document.getElementById('wtb-calendar');
    var modal  = document.getElementById('wtb-modal');
    var close  = document.getElementById('wtb-close');
    var form   = document.getElementById('wtb-form');
    var msgEl  = document.getElementById('wtb-msg');
    var submit = document.getElementById('wtb-submit');

    if (!calEl || !wrap) return;

    var cfg     = window.WTB;
    var slotMin = parseInt(cfg.slot_duration, 10) || 60;

    // Occupied slots almacenados como strings "YYYY-MM-DDTHH:mm:ss" (hora local del sitio)
    // NUNCA como objetos Date — evita conversiones de timezone
    var occupiedStr = []; // [{ start:"2026-05-22T09:00:00", end:"2026-05-22T10:00:00" }]

    // ── Textos dinámicos ──────────────────────────────────────────────────────
    document.getElementById('wtb-modal-title').textContent = cfg.titulo_modal;
    submit.textContent = cfg.btn_texto;

    setF('wtb-tel',   'wtb-lbl-tel',   cfg.label_tel,   cfg.ph_tel,   cfg.campo_tel,  cfg.tel_required);
    setF('wtb-notas', 'wtb-lbl-notas', cfg.label_notas, cfg.ph_notas, cfg.campo_notas, '0');
    applyLabel('wtb-lbl-nombre', cfg.label_nombre + ' *');
    applyInput('wtb-nombre', cfg.ph_nombre, true);
    applyLabel('wtb-lbl-email', cfg.label_email + ' *');
    applyInput('wtb-email', cfg.ph_email, true);

    // ── Límite máximo (como string para evitar conversión UTC) ──────────────
    var maxDateStr = dateAddDays(getTodayStr(), parseInt(cfg.dias_max_futuro,10)||60);

    // ── Botón Reservar ────────────────────────────────────────────────────────
    var openBtn = document.getElementById('wtb-open-btn');
    if (openBtn) {
        if (cfg.open_btn_label) openBtn.textContent = cfg.open_btn_label;
        openBtn.addEventListener('click', function () {
            // Fecha de hoy como string "YYYY-MM-DD" (NO usar new Date().toISOString() → UTC)
            var n = new Date();
            openModal(
                pad(n.getFullYear()) + '-' + pad(n.getMonth()+1) + '-' + pad(n.getDate()),
                null
            );
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  FULLCALENDAR
    // ══════════════════════════════════════════════════════════════════════════
    var calendar = new FullCalendar.Calendar(calEl, {
        initialView  : window.innerWidth <= 768 ? 'timeGridDay' : (cfg.vista || 'timeGridWeek'),
        locale       : 'es',
        timeZone     : cfg.timezone,
        slotMinTime  : cfg.hora_inicio + ':00',
        slotMaxTime  : cfg.hora_fin    + ':00',
        slotDuration : fmtDur(slotMin),
        allDaySlot   : false,
        nowIndicator : true,
        height       : 'auto',
        // Usar string "YYYY-MM-DD" en lugar de new Date() para evitar conversión UTC
        // new Date() en UTC puede ser +1 día vs hora local del sitio (ej: Venezuela UTC-4)
        validRange   : { start: getTodayStr(), end: dateAddDays(getTodayStr(), parseInt(cfg.dias_max_futuro,10)||60) },
        businessHours: { daysOfWeek: cfg.dias, startTime: cfg.hora_inicio+':00', endTime: cfg.hora_fin+':00' },
        headerToolbar: { left:'prev,next today', center:'title', right:'dayGridMonth,timeGridWeek,timeGridDay' },
        buttonText   : { today:'Hoy', month:'Mes', week:'Semana', day:'Día' },
        slotLabelFormat : { hour:'numeric', minute:'2-digit', meridiem:'short', hour12:true },
        selectable: false,
        editable  : false,

        // ── Cargar eventos: startStr/endStr ya están en la timezone del calendario ──
        events: function (info, okCb, failCb) {
            // startStr de FullCalendar ya tiene el offset correcto: "2026-05-18T00:00:00-05:00"
            fetch(
                cfg.api + 'slots'
                    + '?start=' + encodeURIComponent(info.startStr)
                    + '&end='   + encodeURIComponent(info.endStr),
                { headers: { 'X-WP-Nonce': cfg.nonce } }
            )
            .then(function(r){ return r.json(); })
            .then(function(data){
                // Guardar como strings locales: tomar solo los primeros 19 chars "YYYY-MM-DDTHH:mm:ss"
                // El server envía "2026-05-22T09:00:00-05:00" → tomamos "2026-05-22T09:00:00"
                occupiedStr = data.map(function(e){
                    return {
                        start: e.start.substring(0,19),
                        end  : e.end.substring(0,19)
                    };
                });
                okCb(data);
            })
            .catch(failCb);
        },

        // ── Render evento: usar el título del server (ya incluye la hora) ─────
        eventContent: function(arg) {
            var d   = document.createElement('div');
            d.className = 'wtb-ev-block';
            // Icon SVG inline (configurable desde admin)
            var ico = document.createElement('span');
            ico.className = 'wtb-ev-icon';
            if (cfg.lock_icon_char) {
                ico.textContent = cfg.lock_icon_char;
            } else {
                ico.innerHTML = wtbDefaultLockSVG();
            }
            var txt = document.createElement('span');
            txt.className   = 'wtb-ev-txt';
            txt.textContent = arg.event.title;
            d.appendChild(ico);
            d.appendChild(txt);
            return { domNodes:[d] };
        },

        // ── dateStr = hora LOCAL del sitio ya con offset ("2026-05-22T10:00:00-05:00") ──
        dateClick: function(info) {
            // Tomar los primeros 19 chars → "2026-05-22T10:00:00" (hora local del sitio)
            var dtStr    = info.dateStr.substring(0,19); // sin offset
            var datePart = dtStr.substring(0,10);        // "2026-05-22"
            var timePart = dtStr.length > 10 ? dtStr.substring(11,16) : null; // "10:00"

            // Ignorar clics en el pasado (comparación de strings ISO es lexicográfica = correcta)
            if (dtStr < getNowLocalStr()) return;

            openModal(datePart, timePart); // "2026-05-22", "10:00"
        },
    });

    calendar.render();

    // ══════════════════════════════════════════════════════════════════════════
    //  MODAL
    // ══════════════════════════════════════════════════════════════════════════

    /** datePart = "2026-05-22", preselectTime = "10:00" o null */
    function openModal(datePart, preselectTime) {
        form.reset();
        setMsg('', '');
        clearSel();

        var dp = document.getElementById('wtb-date-picker');
        if (dp) {
            dp.value = datePart;
            var todayStr = getTodayStr();
            dp.min = todayStr;
            dp.max = maxDateStr;
        }

        renderGrid(datePart, preselectTime);
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        modal.style.display  = 'none';
        document.body.style.overflow = '';
        clearSel();
    }

    function clearSel() {
        wrap.dataset.selStart = '';
        wrap.dataset.selEnd   = '';
        var si = document.getElementById('wtb-slot-info');
        if (si) { si.textContent = ''; si.className = 'wtb-slot-info-empty'; }
    }

    close.addEventListener('click', closeModal);
    modal.addEventListener('click', function(e){ if(e.target===modal) closeModal(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape'&&modal.style.display!=='none') closeModal(); });

    var dp = document.getElementById('wtb-date-picker');
    if (dp) dp.addEventListener('change', function(){
        if (this.value) renderGrid(this.value, null);
    });

    // ── Grid de horas: opera SOLO con strings, cero Date objects ─────────────
    function renderGrid(datePart, preselectTime) {
        var grid = document.getElementById('wtb-time-grid');
        if (!grid) return;
        grid.innerHTML = '';
        if (!datePart) return;

        // DOW: crear Date al mediodía para evitar ambigüedades DST
        var parts = datePart.split('-');
        var dow = new Date(parseInt(parts[0]), parseInt(parts[1])-1, parseInt(parts[2]), 12).getDay();
        if (cfg.dias.indexOf(dow) === -1) {
            grid.innerHTML = '<p class="wtb-no-slots">Sin disponibilidad este día. Elige un día laborable.</p>';
            return;
        }

        var startH = parseInt(cfg.hora_inicio.split(':')[0], 10);
        var startM = parseInt(cfg.hora_inicio.split(':')[1], 10);
        var endH   = parseInt(cfg.hora_fin.split(':')[0],   10);
        var endM   = parseInt(cfg.hora_fin.split(':')[1],   10);
        var cur    = startH*60 + startM;
        var limit  = endH*60  + endM;
        var nowStr = getNowLocalStr(); // "YYYY-MM-DDTHH:mm:ss" del momento actual (aprox)
        var any    = false;

        while (cur + slotMin <= limit) {
            var h  = Math.floor(cur/60),  m  = cur%60;
            var eh = Math.floor((cur+slotMin)/60), em = (cur+slotMin)%60;

            // Strings locales del slot — NO hay conversión de timezone
            var ssStr = datePart + 'T' + pad(h)  + ':' + pad(m)  + ':00';
            var seStr = datePart + 'T' + pad(eh) + ':' + pad(em) + ':00';

            var isPast = ssStr <= nowStr;
            var isOcc  = isOccupied(ssStr, seStr);
            var dis    = isPast || isOcc;

            // IIFE para capturar ssStr/seStr por valor (evita closure bug)
            (function(slotStart, slotEnd, slotPast, slotOcc, slotDis, hour, min) {
                var btn = document.createElement('button');
                btn.type      = 'button';
                btn.textContent = pad(hour) + ':' + pad(min);
                if (slotOcc) {
                        var lockStr = cfg.lock_icon_char
                            ? '<span class="wtb-time-lock">' + cfg.lock_icon_char + '</span>'
                            : '<span class="wtb-time-lock">' + wtbDefaultLockSVG() + '</span>';
                        btn.innerHTML = pad(hour) + ':' + pad(min) + ' ' + lockStr;
                    }
                btn.className = 'wtb-time-btn ' + (slotDis ? 'wtb-time-disabled' : 'wtb-time-free');
                btn.disabled  = slotDis;
                if (slotPast && !slotOcc) btn.style.opacity = '0.35';

                if (!slotDis) {
                    any = true;
                    btn.addEventListener('click', function(){
                        // Usar 'this' — NO closure sobre btn
                        grid.querySelectorAll('.wtb-time-btn').forEach(function(b){ b.classList.remove('wtb-time-selected'); });
                        this.classList.add('wtb-time-selected');

                        // Guardar strings locales directamente
                        wrap.dataset.selStart = slotStart;
                        wrap.dataset.selEnd   = slotEnd;

                        var si = document.getElementById('wtb-slot-info');
                        if (si) {
                            // Formatear para mostrar: "viernes, 22 de mayo · 10:00 – 11:00"
                            si.textContent = fmtSlotStr(slotStart, slotEnd);
                            si.className   = 'wtb-slot-info-selected';
                        }
                        setMsg('','');
                    });

                    // Pre-seleccionar si coincide (comparar solo HH:mm)
                    if (preselectTime && pad(hour)+':'+pad(min) === preselectTime.substring(0,5)) {
                        btn.click();
                    }
                }
                grid.appendChild(btn);
            })(ssStr, seStr, isPast, isOcc, dis, h, m);

            cur += slotMin;
        }

        if (!any && !grid.querySelector('.wtb-no-slots')) {
            grid.innerHTML = '<p class="wtb-no-slots">Sin franjas libres para este día.</p>';
        }
    }

    /** Comprueba si un slot (strings locales) está ocupado */
    function isOccupied(startStr, endStr) {
        // Comparación lexicográfica de strings ISO — funciona porque el formato es fijo
        return occupiedStr.some(function(ev){
            return ev.start < endStr && ev.end > startStr;
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  ENVÍO
    // ══════════════════════════════════════════════════════════════════════════
    form.addEventListener('submit', function(e){
        e.preventDefault();

        var selStart = wrap.dataset.selStart; // "YYYY-MM-DDTHH:mm:ss" (hora local del sitio)
        var selEnd   = wrap.dataset.selEnd;

        if (!selStart) return setMsg('⏰ Selecciona una hora antes de continuar.', 'error');

        var nombre   = val('wtb-nombre');
        var email    = val('wtb-email');
        var telefono = val('wtb-tel');
        var wa       = val('wtb-whatsapp');
        var notas    = val('wtb-notas');

        if (nombre.length < 2) return setMsg('El nombre debe tener al menos 2 caracteres.', 'error');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setMsg('El email no es válido.', 'error');
        if (cfg.tel_required==='1' && cfg.campo_tel==='1' && !telefono)
            return setMsg('El teléfono es obligatorio.', 'error');

        submit.disabled    = true;
        submit.textContent = 'Enviando…';
        setMsg('','');

        // Enviar strings locales directamente — el server los interpreta con la timezone del sitio
        fetch(cfg.api + 'reservar', {
            method : 'POST',
            headers: { 'Content-Type':'application/json', 'X-WP-Nonce': cfg.nonce },
            body   : JSON.stringify({
                nonce       : cfg.nonce,
                nombre, email,
                telefono    : telefono || wa,
                whatsapp    : wa,
                notas,
                fecha_inicio: selStart,  // "2026-05-22T10:00:00"
                fecha_fin   : selEnd,    // "2026-05-22T11:00:00"
            }),
        })
        .then(function(r){ return r.json().then(function(d){ return {ok:r.ok,data:d}; }); })
        .then(function(r){
            if (r.ok && r.data.success) {
                setMsg(r.data.mensaje, 'success');
                // Añadir inmediatamente a occupiedStr local para bloqueo instantáneo
                occupiedStr.push({ start: selStart, end: selEnd });
                // Refrescar el calendario (el backend ya combinó BD+GCal)
                calendar.refetchEvents();
                setTimeout(closeModal, 3500);
            } else {
                setMsg(r.data.error || 'Error al procesar la reserva.', 'error');
            }
        })
        .catch(function(){ setMsg('Error de conexión. Inténtalo de nuevo.', 'error'); })
        .finally(function(){ submit.disabled=false; submit.textContent=cfg.btn_texto; });
    });

    // ══════════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    function wtbDefaultLockSVG() {
        return '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;opacity:.85"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
    }

    function pad(n){ return String(n).padStart(2,'0'); }

    /** "YYYY-MM-DD" del día de hoy (hora local del navegador — aprox. para validación UX) */
    function getTodayStr(){
        var n=new Date();
        return n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate());
    }

    /** "YYYY-MM-DDTHH:mm:ss" del momento actual (aprox., hora local del navegador) */
    function getNowLocalStr(){
        var n=new Date();
        return n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate())+
               'T'+pad(n.getHours())+':'+pad(n.getMinutes())+':00';
    }

    /** Suma días a un string "YYYY-MM-DD" */
    function dateAddDays(str, days){
        var d = new Date(str+'T12:00:00'); // mediodía evita DST
        d.setDate(d.getDate()+days);
        return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
    }

    function fmtDur(min){
        var h=Math.floor(min/60),r=min%60;
        if(h&&r) return h+':'+pad(r)+':00';
        if(h)    return h+':00:00';
        return '00:'+pad(r)+':00';
    }

    /** Formatea dos strings locales para mostrar en la UI */
    function fmtSlotStr(startStr, endStr){
        // startStr = "2026-05-22T10:00:00"
        var sp = startStr.split('T'), ep = endStr.split('T');
        var dp = sp[0].split('-');
        // Crear Date solo para obtener nombre del día de la semana (sin conversión de horas)
        var dayDate = new Date(parseInt(dp[0]),parseInt(dp[1])-1,parseInt(dp[2]),12);
        var dayName = dayDate.toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'});
        var tStart  = sp[1] ? sp[1].substring(0,5) : '';
        var tEnd    = ep[1] ? ep[1].substring(0,5) : '';
        return dayName + ' · ' + tStart + ' – ' + tEnd;
    }

    function val(id){ var e=document.getElementById(id); return e?(e.value||'').trim():''; }
    function setMsg(t,type){ msgEl.textContent=t; msgEl.className=t?'wtb-msg-'+type:''; }
    function applyLabel(id,t){ var e=document.getElementById(id); if(e) e.textContent=t; }
    function applyInput(id,ph,req){ var e=document.getElementById(id); if(e){e.placeholder=ph;e.required=req;} }
    function setF(fid,lid,label,ph,visible,req){
        var f=document.getElementById(fid),l=document.getElementById(lid);
        var w=f?f.closest('.wtb-f'):null; if(!w) return;
        if(!visible||visible==='0'){w.style.display='none';return;}
        w.style.display='';
        if(l) l.textContent=label+(req==='1'?' *':'');
        if(f){f.placeholder=ph;f.required=req==='1';}
    }
});
