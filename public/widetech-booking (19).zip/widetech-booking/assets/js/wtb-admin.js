/* WIdeTech Booking · Admin JS */
jQuery(function ($) {

    // ══════════════════════════════════════════════════════════════
    //  COLOR PICKERS
    // ══════════════════════════════════════════════════════════════
    $('.wtb-color-picker').wpColorPicker({
        change: function () { setTimeout(updatePreview, 50); },
        clear:  function () { setTimeout(updatePreview, 50); }
    });

    // ══════════════════════════════════════════════════════════════
    //  RANGE SLIDERS — valor en tiempo real
    // ══════════════════════════════════════════════════════════════
    var ranges = [
        { id:'wtb-range-modal',     unit:'px',  el:'#wtb-preview-modal', prop:'border-radius' },
        { id:'wtb-range-btn',       unit:'px',  el:'#wtb-preview-btn',   prop:'border-radius' },
        { id:'wtb-range-cal-radius',unit:'px',  el:'#wtb-preview-cal',   prop:'border-radius' },
        { id:'wtb-range-fs-titulo', unit:'rem', el:'#wtb-preview-title', prop:'font-size' },
        { id:'wtb-range-fs-label',  unit:'rem', el:'.wtb-preview-label', prop:'font-size' },
        { id:'wtb-range-fs-input',  unit:'rem', el:'.wtb-preview-input', prop:'font-size' },
        { id:'wtb-range-fs-btn',    unit:'rem', el:'#wtb-preview-btn',   prop:'font-size' },
    ];
    ranges.forEach(function(r) {
        var $el  = $('#' + r.id);
        var $val = $('#' + r.id + '-val');
        if (!$el.length) return;
        $el.on('input', function () {
            var v = $(this).val();
            if ($val.length) $val.text(v + r.unit);
            if (r.el) $(r.el).css(r.prop, v + r.unit);
        });
    });

    // ══════════════════════════════════════════════════════════════
    //  LIVE PREVIEW — actualizar en tiempo real
    // ══════════════════════════════════════════════════════════════
    function getColor(name) {
        return $('input[name="' + name + '"]').val() || null;
    }

    function updatePreview() {
        var primary = getColor('wtb_color_primario');
        var btnText = getColor('wtb_color_texto_btn');
        var ocupado = getColor('wtb_color_ocupado');
        var rm      = $('#wtb-range-modal').val();
        var rb      = $('#wtb-range-btn').val();

        if (primary) {
            $('#wtb-preview-btn').css('background', primary);
            $('#wtb-cal-view-active').css('background', primary);
            document.documentElement.style.setProperty('--wtb-preview-primary', primary);
        }
        if (btnText)  $('#wtb-preview-btn').css('color', btnText);
        if (ocupado) {
            $('.wtb-cal-slot-occ').css('background', ocupado);
            document.documentElement.style.setProperty('--wtb-preview-ocupado', ocupado);
        }
        if (rm) $('#wtb-preview-modal').css('border-radius', rm + 'px');
        if (rb) $('#wtb-preview-btn').css('border-radius', rb + 'px');
    }

    // Textos en tiempo real
    $('input[name="wtb_titulo_modal"]').on('input', function () {
        $('#wtb-preview-title').text($(this).val() || 'Solicitar cita');
    });
    $('input[name="wtb_btn_texto"]').on('input', function () {
        $('#wtb-preview-btn').text($(this).val() || 'Confirmar reserva');
    });
    $('input[name="wtb_texto_ocupado"]').on('input', function () {
        $('.wtb-occ-text').text($(this).val() || 'No disponible');
    });
    $('input[name="wtb_label_nombre"]').on('input', function () {
        $('#wtb-prev-lbl-nombre').text($(this).val() || 'Nombre completo');
    });
    $('input[name="wtb_label_email"]').on('input', function () {
        $('#wtb-prev-lbl-email').text($(this).val() || 'Correo electrónico');
    });

    // Font selects
    $('select[name="wtb_font_weight_titulo"]').on('change', function () {
        $('#wtb-preview-title').css('font-weight', $(this).val());
    });
    $('select[name="wtb_font_weight_label"]').on('change', function () {
        $('.wtb-preview-label').css('font-weight', $(this).val());
    });
    $('select[name="wtb_font_weight_btn"]').on('change', function () {
        $('#wtb-preview-btn').css('font-weight', $(this).val());
    });
    $('select[name="wtb_font_family"]').on('change', function () {
        var ff = $(this).val();
        $('#wtb-preview, #wtb-preview-cal').css('font-family', ff === 'inherit' ? '' : ff);
        loadGFont(ff);
    });

    function loadGFont(ff) {
        var list = ['Inter','Roboto','Open Sans','Lato','Poppins','Nunito','Montserrat','Raleway','Playfair Display'];
        var match = list.find(function(f){ return ff.indexOf(f) !== -1; });
        if (!match) return;
        var id = 'wtb-gf-' + match.replace(/\s/g,'-');
        if ($('#'+id).length) return;
        $('<link>').attr({ id:id, rel:'stylesheet',
            href:'https://fonts.googleapis.com/css2?family='+encodeURIComponent(match)+':wght@300;400;500;600;700;800&display=swap'
        }).appendTo('head');
    }

    updatePreview();
    // Load font on page load if already selected
    var ff0 = $('select[name="wtb_font_family"]').val();
    if (ff0 && ff0 !== 'inherit') loadGFont(ff0);

    // ══════════════════════════════════════════════════════════════
    //  THEME CARDS — selección visual sin :has()
    // ══════════════════════════════════════════════════════════════
    function initCards(selector, radioName) {
        var $cards = $(selector);

        // Marcar la activa al cargar
        var currentVal = $('input[name="' + radioName + '"]:checked').val();
        $cards.each(function () {
            var $card = $(this);
            var val   = $card.find('input[type="radio"]').val();
            $card.toggleClass('active', val === currentVal);
        });

        // Al hacer clic en la tarjeta (no solo en el radio)
        $cards.on('click', function () {
            var $card = $(this);
            var $radio = $card.find('input[type="radio"]');

            // Marcar el radio
            $radio.prop('checked', true);

            // Actualizar clases .active
            $cards.removeClass('active');
            $card.addClass('active');

            // Disparar change para lógica adicional
            $radio.trigger('change');
        });
    }

    initCards('.wtb-theme-card', 'wtb_theme');
    initCards('.wtb-pos-card',   'wtb_btn_position');

    // ── Mostrar/ocultar opciones custom según tema ────────────────
    function applyCustomOptions(theme) {
        var isCustom = (theme === 'custom');
        $('#wtb-custom-options').css({
            'opacity'       : isCustom ? '1'   : '0.4',
            'pointer-events': isCustom ? 'all' : 'none',
            'transition'    : 'opacity .2s',
        });
    }

    // Al cargar la página
    applyCustomOptions($('input[name="wtb_theme"]:checked').val() || 'light');

    // Al cambiar el tema
    $(document).on('change', 'input[name="wtb_theme"]', function () {
        applyCustomOptions($(this).val());
    });

    // ══════════════════════════════════════════════════════════════
    //  DAYS PILLS
    // ══════════════════════════════════════════════════════════════
    // Marcar activas al cargar
    $('.wtb-day-pill input[type="checkbox"]').each(function () {
        $(this).closest('.wtb-day-pill').toggleClass('active', this.checked);
    });

    $(document).on('change', '.wtb-day-pill input[type="checkbox"]', function () {
        $(this).closest('.wtb-day-pill').toggleClass('active', this.checked);
    });

    // ══════════════════════════════════════════════════════════════
    //  COPIAR SHORTCODE
    // ══════════════════════════════════════════════════════════════
    window.wtbCopy = function (id) {
        var text = document.getElementById(id) ? document.getElementById(id).textContent : '';
        navigator.clipboard.writeText(text).then(function () {
            var btn = event.target;
            var orig = btn.textContent;
            btn.textContent    = '¡Copiado!';
            btn.style.background = '#16a34a';
            setTimeout(function () { btn.textContent = orig; btn.style.background = ''; }, 2000);
        });
    };

    // ══════════════════════════════════════════════════════════════
    //  TEST DE CONEXIÓN GOOGLE
    // ══════════════════════════════════════════════════════════════
    $('#wtb-test-btn').on('click', function () {
        var $btn = $(this);
        var $res = $('#wtb-test-result');
        $btn.prop('disabled', true).text('Probando…');
        $res.removeClass('ok err').text('');

        $.ajax({
            url   : WTB_Admin.api + 'test-connection',
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', WTB_Admin.nonce);
            },
            success: function (data) {
                $res.addClass(data.ok ? 'ok' : 'err').html(data.msg);
            },
            error: function (xhr) {
                var d = xhr.responseJSON || {};
                $res.addClass('err').text(d.msg || 'Error al conectar con Google.');
            },
            complete: function () {
                $btn.prop('disabled', false).text('🔌 Probar conexión');
            }
        });
    });

    // ══════════════════════════════════════════════════════════════
    //  DESCONECTAR GOOGLE — confirmación
    // ══════════════════════════════════════════════════════════════
    $(document).on('click', '.wtb-link-danger', function (e) {
        if (!confirm('¿Seguro que quieres desconectar Google Calendar?')) e.preventDefault();
    });

    // ══════════════════════════════════════════════════════════════
    //  AUTO-DISMISS alertas de éxito
    // ══════════════════════════════════════════════════════════════
    setTimeout(function () { $('.wtb-alert-success').fadeOut(600); }, 4000);

});

// ── Icon pill selection ───────────────────────────────────────
$(document).on('click', '.wtb-icon-pill', function() {
    var $pill  = $(this);
    var $group = $pill.closest('td').find('.wtb-icon-pill');
    $group.removeClass('active');
    $pill.addClass('active');
    $pill.find('input[type="radio"]').prop('checked', true);
});
